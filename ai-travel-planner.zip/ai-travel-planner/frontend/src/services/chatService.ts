import api from './api';
import { ChatMessage, ChatResponse } from '../types';

export const chatService = {
  async sendMessage(tripId: string, message: string): Promise<ChatResponse> {
    const res = await api.post<ChatResponse>(`/trips/${tripId}/chat`, { message });
    return res.data;
  },

  async getConversation(tripId: string): Promise<ChatMessage[]> {
    const res = await api.get<ChatMessage[]>(`/trips/${tripId}/conversation`);
    return res.data;
  },
};
