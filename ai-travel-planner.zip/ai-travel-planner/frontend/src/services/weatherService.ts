import api from './api';
import { WeatherData } from '../types';

export const weatherService = {
  async getWeather(destination: string, days: number = 7): Promise<WeatherData> {
    const res = await api.get<WeatherData>('/weather', {
      params: { destination, days },
    });
    return res.data;
  },
};
