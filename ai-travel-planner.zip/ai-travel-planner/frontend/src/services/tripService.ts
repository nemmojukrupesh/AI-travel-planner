import api from './api';
import { Trip, TripItinerary, TripPreferences } from '../types';

export interface CreateTripPayload {
  destination: string;
  start_date: string;
  end_date: string;
  travelers: number;
  budget: number;
  currency: string;
  travel_style: string;
  preferences?: TripPreferences;
}

export const tripService = {
  async createTrip(payload: CreateTripPayload): Promise<Trip> {
    const res = await api.post<Trip>('/trips', payload);
    return res.data;
  },

  async getTrips(): Promise<Trip[]> {
    const res = await api.get<Trip[]>('/trips');
    return res.data;
  },

  async getTrip(tripId: string): Promise<Trip> {
    const res = await api.get<Trip>(`/trips/${tripId}`);
    return res.data;
  },

  async deleteTrip(tripId: string): Promise<void> {
    await api.delete(`/trips/${tripId}`);
  },

  async duplicateTrip(tripId: string): Promise<Trip> {
    const res = await api.post<Trip>(`/trips/${tripId}/duplicate`);
    return res.data;
  },

  async generateItinerary(tripId: string): Promise<TripItinerary> {
    const res = await api.post<TripItinerary>(`/trips/${tripId}/generate`);
    return res.data;
  },

  async regenerateItinerary(tripId: string): Promise<TripItinerary> {
    const res = await api.post<TripItinerary>(`/trips/${tripId}/regenerate`);
    return res.data;
  },

  async restoreVersion(tripId: string, versionNumber: number): Promise<TripItinerary> {
    const res = await api.post<TripItinerary>(`/trips/${tripId}/versions/${versionNumber}/restore`);
    return res.data;
  },

  async optimizeBudget(tripId: string): Promise<{ optimized_itinerary: TripItinerary; changes_made: string[] }> {
    const res = await api.post(`/trips/${tripId}/budget/optimize`);
    return res.data;
  },
};
