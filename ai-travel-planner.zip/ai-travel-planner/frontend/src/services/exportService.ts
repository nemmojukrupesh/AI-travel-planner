import api from './api';

export const exportService = {
  getExportJsonUrl(tripId: string): string {
    return `${api.defaults.baseURL}/trips/${tripId}/export/json`;
  },

  getExportPdfUrl(tripId: string): string {
    return `${api.defaults.baseURL}/trips/${tripId}/export/pdf`;
  },

  async downloadJson(tripId: string, filename: string): Promise<void> {
    const res = await api.get(`/trips/${tripId}/export/json`, {
      responseType: 'blob',
    });
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${filename}.json`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },

  async downloadPdf(tripId: string, filename: string): Promise<void> {
    const res = await api.get(`/trips/${tripId}/export/pdf`, {
      responseType: 'blob',
    });
    const url = window.URL.createObjectURL(new Blob([res.data], { type: 'application/pdf' }));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${filename}.pdf`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  },
};
