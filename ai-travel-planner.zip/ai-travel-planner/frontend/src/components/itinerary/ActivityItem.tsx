import React from 'react';
import { Clock, DollarSign, MapPin, CheckCircle2, ShieldAlert, Footprints, Car, Train, Navigation, Star } from 'lucide-react';
import { ActivityItem as ActivityItemType } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface ActivityCardProps {
  activity: ActivityItemType;
  currency?: string;
}

export const ActivityItemCard: React.FC<ActivityCardProps> = ({ activity, currency = 'USD' }) => {
  const getCategoryColor = (cat: string) => {
    switch (cat.toLowerCase()) {
      case 'historical':
        return 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      case 'museum':
        return 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'food':
        return 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800';
      case 'nature':
        return 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
      case 'shopping':
        return 'bg-sky-100 dark:bg-sky-950/60 text-sky-800 dark:text-sky-300 border-sky-200 dark:border-sky-800';
      default:
        return 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700';
    }
  };

  return (
    <div className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm hover:shadow-md hover:border-brand-300 dark:hover:border-brand-700 transition-all">
      {/* Transit Connector if present */}
      {activity.travel_from_prev && (
        <div className="mb-3 -mt-1 p-2 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-dashed border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1.5 font-medium">
            {activity.travel_from_prev.mode === 'walk' ? (
              <Footprints className="w-3.5 h-3.5 text-emerald-500" />
            ) : activity.travel_from_prev.mode === 'cab' ? (
              <Car className="w-3.5 h-3.5 text-amber-500" />
            ) : (
              <Train className="w-3.5 h-3.5 text-brand-500" />
            )}
            <span>Transit from {activity.travel_from_prev.from_name}:</span>
            <span className="text-slate-800 dark:text-slate-200 font-semibold">{activity.travel_from_prev.duration_minutes} mins</span>
            <span>({activity.travel_from_prev.distance_km} km)</span>
          </div>
          {activity.travel_from_prev.estimated_cost > 0 && (
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              ~{formatCurrency(activity.travel_from_prev.estimated_cost, currency)}
            </span>
          )}
        </div>
      )}

      {/* Main Activity Header */}
      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2 mb-2.5">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300 border border-brand-200 dark:border-brand-800">
              <Clock className="w-3 h-3" />
              {activity.start_time} ({activity.duration_minutes}m)
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getCategoryColor(activity.category)}`}>
              {activity.category.toUpperCase()}
            </span>
            {activity.is_indoor && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                Indoor / Sheltered
              </span>
            )}
          </div>
          <h4 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
            {activity.name}
          </h4>
        </div>

        {/* Cost & Rating */}
        <div className="flex items-center sm:flex-col sm:items-end justify-between gap-1 text-right">
          <span className="text-sm font-extrabold text-slate-900 dark:text-white">
            {activity.estimated_cost === 0 ? 'Free' : formatCurrency(activity.estimated_cost, currency)}
          </span>
          <div className="flex items-center gap-1 text-xs text-amber-500 font-semibold">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span>{activity.rating || 4.5}</span>
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
        {activity.description}
      </p>

      {/* Rationale / Grounded Context */}
      {activity.reason && (
        <div className="text-xs text-brand-700 dark:text-brand-300 bg-brand-50/50 dark:bg-brand-950/30 p-2.5 rounded-lg border border-brand-100 dark:border-brand-900/50">
          <span className="font-semibold">AI Match: </span>
          {activity.reason}
        </div>
      )}
    </div>
  );
};
