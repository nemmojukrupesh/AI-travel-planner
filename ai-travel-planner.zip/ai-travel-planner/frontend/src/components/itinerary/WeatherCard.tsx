import React from 'react';
import { CloudSun, Droplets, Thermometer, ShieldCheck, Umbrella } from 'lucide-react';
import { DayPlan } from '../../types';
import { formatDate } from '../../utils/formatters';

interface WeatherCardProps {
  days: DayPlan[];
}

export const WeatherOverviewCard: React.FC<WeatherCardProps> = ({ days }) => {
  return (
    <div className="glass-card p-6 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400">
            <CloudSun className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Weather Forecast & Outdoor Advisory</h3>
            <p className="text-xs text-slate-500">Real-time meteorological analysis by Weather Agent</p>
          </div>
        </div>
      </div>

      {/* Daily Weather Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {days.map((day) => {
          const w = day.weather;
          return (
            <div
              key={day.day}
              className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 flex flex-col justify-between gap-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Day {day.day} ({formatDate(day.date)})
                </span>
                <span className="text-xs font-extrabold text-brand-600 dark:text-brand-400">
                  {w.temperature_c}°C
                </span>
              </div>

              <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
                <CloudSun className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="truncate">{w.condition}</span>
              </div>

              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1 text-slate-500">
                  <Droplets className="w-3 h-3 text-sky-500" />
                  <span>Rain {w.rain_probability_pct}%</span>
                </div>
                <div>
                  {w.is_favorable_for_outdoor ? (
                    <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
                      <ShieldCheck className="w-3 h-3" /> Outdoor Ready
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-amber-600 dark:text-amber-400 font-semibold">
                      <Umbrella className="w-3 h-3" /> Indoor Alert
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
