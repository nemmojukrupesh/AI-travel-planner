import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { MapPin, Navigation } from 'lucide-react';
import { TripItinerary } from '../../types';

// Fix for default Leaflet icon paths in Vite
const customIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

const hotelIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-violet.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

interface MapViewProps {
  itinerary: TripItinerary;
}

// Helper to auto-center map bounds
const ChangeView: React.FC<{ center: [number, number]; zoom: number }> = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
};

export const MapView: React.FC<MapViewProps> = ({ itinerary }) => {
  // Extract all markers
  const markers: Array<{
    id: string;
    title: string;
    category: string;
    day?: number;
    lat: number;
    lng: number;
    isHotel?: boolean;
  }> = [];

  // Add hotel marker
  if (itinerary.hotel?.location?.latitude && itinerary.hotel?.location?.longitude) {
    markers.push({
      id: 'hotel',
      title: itinerary.hotel.name,
      category: 'Accommodation',
      lat: itinerary.hotel.location.latitude,
      lng: itinerary.hotel.location.longitude,
      isHotel: true,
    });
  }

  // Add daily activities
  itinerary.days.forEach((day) => {
    const allActs = [...day.morning_activities, ...day.afternoon_activities, ...day.evening_activities];
    allActs.forEach((act, idx) => {
      if (act.location?.latitude && act.location?.longitude) {
        markers.push({
          id: `d${day.day}-a${idx}`,
          title: act.name,
          category: act.category,
          day: day.day,
          lat: act.location.latitude,
          lng: act.location.longitude,
        });
      }
    });
  });

  const centerLat = markers.length > 0 ? markers[0].lat : 17.385;
  const centerLng = markers.length > 0 ? markers[0].lng : 78.4867;

  return (
    <div className="glass-card p-4 sm:p-6 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-brand-100 dark:bg-brand-950 text-brand-600 dark:text-brand-400">
            <Navigation className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Geographic Activity Map</h3>
            <p className="text-xs text-slate-500">Route & cluster visualization optimized by Route Agent</p>
          </div>
        </div>
      </div>

      <div className="h-80 w-full rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 relative z-0 shadow-inner">
        <MapContainer
          center={[centerLat, centerLng]}
          zoom={12}
          scrollWheelZoom={false}
          className="h-full w-full"
        >
          <ChangeView center={[centerLat, centerLng]} zoom={12} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          {markers.map((m) => (
            <Marker
              key={m.id}
              position={[m.lat, m.lng]}
              icon={m.isHotel ? hotelIcon : customIcon}
            >
              <Popup>
                <div className="p-1">
                  <div className="text-xs font-bold text-slate-900">{m.title}</div>
                  <div className="text-[10px] text-slate-500 font-medium">
                    {m.isHotel ? 'Accommodation' : `Day ${m.day} · ${m.category.toUpperCase()}`}
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </div>
  );
};
