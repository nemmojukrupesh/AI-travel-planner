import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';
import { DollarSign, AlertTriangle, CheckCircle, ArrowDownRight, Sparkles, TrendingDown } from 'lucide-react';
import { BudgetBreakdown } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface BudgetOverviewProps {
  breakdown: BudgetBreakdown;
  onOptimizeBudget?: () => void;
  isOptimizing?: boolean;
}

const COLORS = ['#0284c7', '#10b981', '#f59e0b', '#8b5cf6', '#64748b'];

export const BudgetOverview: React.FC<BudgetOverviewProps> = ({
  breakdown,
  onOptimizeBudget,
  isOptimizing = false,
}) => {
  const currency = breakdown.currency || 'USD';

  const chartData = [
    { name: 'Accommodation', value: breakdown.accommodation },
    { name: 'Dining & Food', value: breakdown.food },
    { name: 'Activities', value: breakdown.activities },
    { name: 'Transport', value: breakdown.transport },
    { name: 'Buffer / Misc', value: breakdown.miscellaneous },
  ].filter((item) => item.value > 0);

  const budgetUsagePct = Math.round((breakdown.total_estimated / Math.max(1, breakdown.user_budget)) * 100);

  return (
    <div className="glass-card p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Budget & Expense Allocation</h3>
            <p className="text-xs text-slate-500">Calculated by Budget Agent</p>
          </div>
        </div>

        {/* Action Button for Budget Optimization */}
        {breakdown.is_over_budget && onOptimizeBudget && (
          <button
            onClick={onOptimizeBudget}
            disabled={isOptimizing}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs shadow-sm flex items-center gap-2 transition-all hover:scale-105"
          >
            <TrendingDown className="w-4 h-4" />
            <span>{isOptimizing ? 'Optimizing...' : 'Auto-Optimize Budget'}</span>
          </button>
        )}
      </div>

      {/* Top Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Estimated Total */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Estimated Total</span>
          <div className="text-xl font-extrabold text-slate-900 dark:text-white mt-1">
            {formatCurrency(breakdown.total_estimated, currency)}
          </div>
          <span className="text-xs text-slate-400 font-medium">{budgetUsagePct}% of your target budget</span>
        </div>

        {/* Target Budget */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Target Budget</span>
          <div className="text-xl font-extrabold text-brand-600 dark:text-brand-400 mt-1">
            {formatCurrency(breakdown.user_budget, currency)}
          </div>
          <span className="text-xs text-slate-400 font-medium">Configured maximum limit</span>
        </div>

        {/* Budget Status */}
        <div
          className={`p-4 rounded-xl border ${
            breakdown.is_over_budget
              ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300'
              : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300'
          }`}
        >
          <span className="text-xs font-semibold uppercase tracking-wider">Status</span>
          <div className="flex items-center gap-1.5 text-lg font-bold mt-1">
            {breakdown.is_over_budget ? (
              <>
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
                <span>Over Budget (+{formatCurrency(breakdown.overrun_amount, currency)})</span>
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Within Budget</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Recharts Pie & Category Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center pt-2">
        {/* Pie Chart */}
        <div className="h-56 w-full flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={4}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(val: number) => formatCurrency(val, currency)}
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderRadius: '0.75rem',
                  border: 'none',
                  color: '#fff',
                  fontSize: '0.75rem',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Category List */}
        <div className="space-y-2.5">
          {chartData.map((item, idx) => (
            <div
              key={item.name}
              className="flex items-center justify-between text-xs sm:text-sm p-2 rounded-lg bg-slate-50/60 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800"
            >
              <div className="flex items-center gap-2">
                <span
                  className="w-3 h-3 rounded-full shrink-0"
                  style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                />
                <span className="font-medium text-slate-700 dark:text-slate-300">{item.name}</span>
              </div>
              <span className="font-bold text-slate-900 dark:text-white">
                {formatCurrency(item.value, currency)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Savings Suggestions */}
      {breakdown.savings_suggestions && breakdown.savings_suggestions.length > 0 && (
        <div className="p-4 rounded-xl bg-brand-50/60 dark:bg-brand-950/40 border border-brand-200/80 dark:border-brand-900 text-xs text-brand-900 dark:text-brand-300 space-y-1.5">
          <div className="font-bold flex items-center gap-1.5 text-brand-800 dark:text-brand-200">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Budget Agent Insights & Recommendations:</span>
          </div>
          <ul className="list-disc list-inside space-y-1 text-slate-600 dark:text-slate-300">
            {breakdown.savings_suggestions.map((s, idx) => (
              <li key={idx}>{s}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
