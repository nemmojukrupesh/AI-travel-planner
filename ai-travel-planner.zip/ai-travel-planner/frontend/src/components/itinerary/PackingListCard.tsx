import React, { useState } from 'react';
import { Luggage, CheckSquare, Square } from 'lucide-react';

interface PackingListCardProps {
  suggestions: string[];
}

export const PackingListCard: React.FC<PackingListCardProps> = ({ suggestions }) => {
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});

  const toggleCheck = (index: number) => {
    setCheckedItems((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  return (
    <div className="glass-card p-6 space-y-4">
      <div className="flex items-center gap-2.5 border-b border-slate-100 dark:border-slate-800 pb-3">
        <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
          <Luggage className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">Smart Packing Checklist</h3>
          <p className="text-xs text-slate-500">Weather & destination tailored essentials</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {suggestions.map((item, idx) => {
          const isChecked = !!checkedItems[idx];
          return (
            <button
              key={idx}
              type="button"
              onClick={() => toggleCheck(idx)}
              className={`p-3 rounded-xl border text-left flex items-center gap-3 transition-all ${
                isChecked
                  ? 'bg-slate-100 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-400 line-through'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:border-brand-400'
              }`}
            >
              {isChecked ? (
                <CheckSquare className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0" />
              ) : (
                <Square className="w-4 h-4 text-slate-400 shrink-0" />
              )}
              <span className="text-xs font-medium">{item}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
