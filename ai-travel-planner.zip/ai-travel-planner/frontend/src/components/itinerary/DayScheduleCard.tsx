import React from 'react';
import { Sun, Sunset, Moon, Utensils, CloudSun, Lightbulb, MapPin, DollarSign } from 'lucide-react';
import { DayPlan } from '../../types';
import { ActivityItemCard } from './ActivityItem';
import { formatCurrency, formatDate } from '../../utils/formatters';

interface DayScheduleCardProps {
  dayPlan: DayPlan;
  currency?: string;
}

export const DayScheduleCard: React.FC<DayScheduleCardProps> = ({ dayPlan, currency = 'USD' }) => {
  return (
    <div className="glass-card overflow-hidden transition-all border-slate-200/80 dark:border-slate-800/80">
      {/* Day Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 text-white p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-brand-500/20 border border-brand-400/30 flex items-center justify-center font-extrabold text-xl text-brand-300">
              D{dayPlan.day}
            </div>
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-brand-400">
                {formatDate(dayPlan.date)}
              </span>
              <h3 className="text-lg sm:text-xl font-extrabold text-white">
                {dayPlan.theme}
              </h3>
            </div>
          </div>

          {/* Weather Badge */}
          {dayPlan.weather && (
            <div className="flex items-center gap-2.5 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-white/10 text-xs">
              <CloudSun className="w-4 h-4 text-amber-300" />
              <div>
                <span className="font-bold text-white">{dayPlan.weather.temperature_c}°C</span>
                <span className="text-slate-300 ml-1">· {dayPlan.weather.condition}</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Schedule Body */}
      <div className="p-5 sm:p-6 space-y-6">
        {/* Morning Block */}
        {dayPlan.morning_activities.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              <Sun className="w-4 h-4" />
              <span>Morning Exploration</span>
            </div>
            <div className="space-y-3 pl-2 sm:pl-4 border-l-2 border-amber-200 dark:border-amber-900/60">
              {dayPlan.morning_activities.map((act, idx) => (
                <ActivityItemCard key={idx} activity={act} currency={currency} />
              ))}
            </div>
          </div>
        )}

        {/* Lunch & Dining Midday */}
        {dayPlan.meals.filter((m) => m.meal_type === 'lunch').length > 0 && (
          <div className="bg-rose-50/50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 mb-2">
              <Utensils className="w-3.5 h-3.5" />
              <span>Curated Lunch Recommendation</span>
            </div>
            {dayPlan.meals
              .filter((m) => m.meal_type === 'lunch')
              .map((m, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">
                      {m.restaurant_name} <span className="text-xs text-slate-500 font-normal">({m.cuisine})</span>
                    </h5>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Must Try: <span className="font-semibold text-rose-700 dark:text-rose-300">{m.recommended_dish}</span>
                    </p>
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    ~{formatCurrency(m.estimated_cost, currency)}
                  </span>
                </div>
              ))}
          </div>
        )}

        {/* Afternoon Block */}
        {dayPlan.afternoon_activities.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">
              <Sunset className="w-4 h-4" />
              <span>Afternoon Highlights</span>
            </div>
            <div className="space-y-3 pl-2 sm:pl-4 border-l-2 border-sky-200 dark:border-sky-900/60">
              {dayPlan.afternoon_activities.map((act, idx) => (
                <ActivityItemCard key={idx} activity={act} currency={currency} />
              ))}
            </div>
          </div>
        )}

        {/* Evening Block */}
        {dayPlan.evening_activities.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
              <Moon className="w-4 h-4" />
              <span>Evening Atmosphere</span>
            </div>
            <div className="space-y-3 pl-2 sm:pl-4 border-l-2 border-purple-200 dark:border-purple-900/60">
              {dayPlan.evening_activities.map((act, idx) => (
                <ActivityItemCard key={idx} activity={act} currency={currency} />
              ))}
            </div>
          </div>
        )}

        {/* Dinner & Evening Dining */}
        {dayPlan.meals.filter((m) => m.meal_type === 'dinner').length > 0 && (
          <div className="bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-xl p-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 mb-2">
              <Utensils className="w-3.5 h-3.5" />
              <span>Evening Dining Experience</span>
            </div>
            {dayPlan.meals
              .filter((m) => m.meal_type === 'dinner')
              .map((m, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">
                      {m.restaurant_name} <span className="text-xs text-slate-500 font-normal">({m.cuisine})</span>
                    </h5>
                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Recommended: <span className="font-semibold text-indigo-700 dark:text-indigo-300">{m.recommended_dish}</span>
                    </p>
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    ~{formatCurrency(m.estimated_cost, currency)}
                  </span>
                </div>
              ))}
          </div>
        )}

        {/* Local Day Tips */}
        {dayPlan.day_tips && dayPlan.day_tips.length > 0 && (
          <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-900/50 text-xs text-amber-900 dark:text-amber-300">
            <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Daily Local Tip: </span>
              <span>{dayPlan.day_tips.join(' · ')}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
