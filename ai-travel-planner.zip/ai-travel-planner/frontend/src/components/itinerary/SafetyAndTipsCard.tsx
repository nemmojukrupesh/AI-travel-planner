import React from 'react';
import { ShieldCheck, Compass, Info, CheckCircle2 } from 'lucide-react';

interface SafetyAndTipsCardProps {
  safety: string[];
  localTips: string[];
}

export const SafetyAndTipsCard: React.FC<SafetyAndTipsCardProps> = ({ safety, localTips }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Local Safety Tips */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2.5 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Safety & Transit Guidelines</h3>
            <p className="text-xs text-slate-500">Destination safety intelligence</p>
          </div>
        </div>

        <ul className="space-y-2.5">
          {safety.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Local Cultural Advice */}
      <div className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2.5 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Local Etiquette & Travel Tips</h3>
            <p className="text-xs text-slate-500">Grounded advice for smooth travel</p>
          </div>
        </div>

        <ul className="space-y-2.5">
          {localTips.map((item, idx) => (
            <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300">
              <Compass className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
