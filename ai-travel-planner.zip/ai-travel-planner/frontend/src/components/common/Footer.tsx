import React from 'react';
import { Compass, Sparkles, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-white dark:bg-slate-950 border-t border-slate-200/80 dark:border-slate-800/80 py-10 mt-auto transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white">
            <Compass className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg text-slate-800 dark:text-slate-200">
            Voyage<span className="text-brand-500">AI</span>
          </span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400 border border-brand-200 dark:border-brand-800">
            v1.0 Production
          </span>
        </div>

        {/* Info */}
        <p className="text-xs text-slate-500 dark:text-slate-400 text-center md:text-left flex items-center gap-1">
          Built with <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Multi-Agent AI & Grounded RAG Architecture.
        </p>

        {/* Links */}
        <div className="flex items-center gap-6 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Link to="/planner" className="hover:text-brand-500 transition-colors">Plan Trip</Link>
          <Link to="/saved" className="hover:text-brand-500 transition-colors">Saved Itineraries</Link>
          <a href="#features" className="hover:text-brand-500 transition-colors">Architecture</a>
        </div>
      </div>
    </footer>
  );
};
