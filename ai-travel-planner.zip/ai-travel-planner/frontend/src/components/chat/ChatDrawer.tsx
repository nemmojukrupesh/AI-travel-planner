import React, { useState, useEffect, useRef } from 'react';
import { X, Send, Sparkles, History, Bot, Loader2, RefreshCw } from 'lucide-react';
import { ChatMessage, ItineraryVersion } from '../../types';
import { ChatMessageItem } from './ChatMessage';
import { VersionHistoryModal } from './VersionHistoryModal';
import { chatService } from '../../services/chatService';

interface ChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  tripId: string;
  destination: string;
  currentVersion: number;
  versions: ItineraryVersion[];
  onItineraryUpdated: () => void;
  currency: string;
}

const QUICK_PROMPTS = [
  'Make Day 2 cheaper',
  'Add more historical places',
  'Remove the museum',
  'Keep travel times under 30 mins',
  'Add more local food spots',
];

export const ChatDrawer: React.FC<ChatDrawerProps> = ({
  isOpen,
  onClose,
  tripId,
  destination,
  currentVersion,
  versions,
  onItineraryUpdated,
  currency,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load chat history on mount / open
  useEffect(() => {
    if (isOpen && tripId) {
      chatService.getConversation(tripId)
        .then((data) => {
          if (data && data.length > 0) {
            setMessages(data);
          } else {
            // Initial greeting
            setMessages([
              {
                role: 'assistant',
                message: `Hi! I'm your AI Travel Assistant for **${destination}**. You can ask me to modify any part of your itinerary in plain English—for example: *"Make Day 2 cheaper"*, *"Add more historical places"*, or *"Reduce travel times between stops"*. How can I help refine your journey?`,
              },
            ]);
          }
        })
        .catch(() => {});
    }
  }, [isOpen, tripId, destination]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || isSending) return;

    const userMsg: ChatMessage = { role: 'user', message: text };
    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsSending(true);

    try {
      const res = await chatService.sendMessage(tripId, text);
      const assistantMsg: ChatMessage = { role: 'assistant', message: res.reply };
      setMessages((prev) => [...prev, assistantMsg]);
      onItineraryUpdated();
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          message: 'Sorry, I encountered an issue updating your itinerary. Please try again!',
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col animate-slideLeft">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-brand-600 to-sky-400 flex items-center justify-center text-white shadow-md shadow-brand-500/20">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 dark:text-white flex items-center gap-2">
                Travel Assistant Agent
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                  Online
                </span>
              </h3>
              <span className="text-xs text-slate-400">Version {currentVersion} active</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsHistoryOpen(true)}
              title="Version History"
              className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <History className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
          {messages.map((m, idx) => (
            <ChatMessageItem key={idx} message={m} />
          ))}

          {isSending && (
            <div className="flex items-center gap-3 animate-fadeIn">
              <div className="w-8 h-8 rounded-xl bg-brand-600 flex items-center justify-center text-white shrink-0">
                <Loader2 className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl px-4 py-2.5 text-xs text-slate-600 dark:text-slate-400 font-medium">
                Assistant is updating your itinerary...
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/30 overflow-x-auto whitespace-nowrap scrollbar-none flex gap-2">
          {QUICK_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              disabled={isSending}
              onClick={() => handleSendMessage(prompt)}
              className="text-xs px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-brand-500 hover:text-brand-600 dark:hover:text-brand-400 transition-colors shrink-0"
            >
              ✨ {prompt}
            </button>
          ))}
        </div>

        {/* Chat Input */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="e.g. Make Day 2 cheaper, swap museums..."
              disabled={isSending}
              className="flex-1 px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim() || isSending}
              className="p-3 rounded-xl bg-brand-600 hover:bg-brand-500 text-white shadow-md shadow-brand-500/20 disabled:opacity-50 transition-all hover:scale-105"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>

      {/* Version History Modal */}
      <VersionHistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        versions={versions}
        currentVersion={currentVersion}
        onRestoreVersion={() => onItineraryUpdated()}
        currency={currency}
      />
    </>
  );
};
