import React from 'react';
import { X, History, RotateCcw, CheckCircle2 } from 'lucide-react';
import { ItineraryVersion } from '../../types';
import { formatCurrency } from '../../utils/formatters';

interface VersionHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  versions: ItineraryVersion[];
  currentVersion: number;
  onRestoreVersion: (versionNum: number) => void;
  currency: string;
}

export const VersionHistoryModal: React.FC<VersionHistoryModalProps> = ({
  isOpen,
  onClose,
  versions,
  currentVersion,
  onRestoreVersion,
  currency,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-brand-100 dark:bg-brand-950 text-brand-600 dark:text-brand-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Itinerary Version History</h3>
              <p className="text-xs text-slate-500">Track modifications & restore earlier plans</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Version List */}
        <div className="p-5 max-h-96 overflow-y-auto space-y-3">
          {versions.map((ver) => {
            const isCurrent = ver.version === currentVersion;
            return (
              <div
                key={ver.version}
                className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all ${
                  isCurrent
                    ? 'border-brand-500 bg-brand-50/50 dark:bg-brand-950/40'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                      Version {ver.version}
                    </span>
                    {isCurrent && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-brand-100 dark:bg-brand-900 text-brand-700 dark:text-brand-300">
                        <CheckCircle2 className="w-3 h-3" /> Active
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    {ver.change_summary || 'Itinerary update'}
                  </p>
                  <span className="text-[11px] font-semibold text-slate-500 mt-1 block">
                    Total: {formatCurrency(ver.estimated_cost, currency)}
                  </span>
                </div>

                {!isCurrent && (
                  <button
                    onClick={() => {
                      onRestoreVersion(ver.version);
                      onClose();
                    }}
                    className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-brand-600 hover:text-white hover:border-brand-600 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore</span>
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
