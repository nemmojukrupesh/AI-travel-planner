import React, { useState, useEffect } from 'react';
import { CheckCircle2, Loader2, Sparkles, MapPin, CloudSun, Compass, Utensils, DollarSign, FileText } from 'lucide-react';

interface GenerationProgressProps {
  destination: string;
  onComplete?: () => void;
}

interface StepItem {
  id: string;
  title: string;
  icon: React.ReactNode;
  agent: string;
  durationMs: number;
}

export const GenerationProgress: React.FC<GenerationProgressProps> = ({ destination }) => {
  const steps: StepItem[] = [
    { id: '1', title: 'Analyzing Destination Context & Safety', icon: <MapPin className="w-5 h-5" />, agent: 'Destination Agent', durationMs: 700 },
    { id: '2', title: 'Curating Top Attractions & Experiences', icon: <Compass className="w-5 h-5" />, agent: 'Activity Agent', durationMs: 800 },
    { id: '3', title: 'Fetching Climate Data & Weather Forecast', icon: <CloudSun className="w-5 h-5" />, agent: 'Weather Agent', durationMs: 700 },
    { id: '4', title: 'Optimizing Routes & Minimizing Travel Times', icon: <Compass className="w-5 h-5" />, agent: 'Route Optimization Agent', durationMs: 800 },
    { id: '5', title: 'Pairing Iconic Regional Cuisine & Dining', icon: <Utensils className="w-5 h-5" />, agent: 'Food Agent', durationMs: 700 },
    { id: '6', title: 'Validating Expenses & Allocating Budget', icon: <DollarSign className="w-5 h-5" />, agent: 'Budget Agent', durationMs: 700 },
    { id: '7', title: 'Synthesizing Final Structured Itinerary', icon: <FileText className="w-5 h-5" />, agent: 'Itinerary Agent', durationMs: 900 },
  ];

  const [activeStepIndex, setActiveStepIndex] = useState<number>(0);

  useEffect(() => {
    if (activeStepIndex < steps.length - 1) {
      const timer = setTimeout(() => {
        setActiveStepIndex((prev) => prev + 1);
      }, steps[activeStepIndex].durationMs);
      return () => clearTimeout(timer);
    }
  }, [activeStepIndex]);

  return (
    <div className="max-w-xl mx-auto glass-card p-8 text-center animate-fadeIn">
      {/* Header */}
      <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-brand-600 to-sky-400 flex items-center justify-center text-white shadow-lg shadow-brand-500/25 mb-5">
        <Sparkles className="w-8 h-8 animate-spin" style={{ animationDuration: '6s' }} />
      </div>
      <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-2">
        AI Multi-Agent Team Planning Trip
      </h2>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-8">
        Crafting a personalized, weather-aware, and route-optimized journey to <span className="font-semibold text-brand-600 dark:text-brand-400">{destination}</span>.
      </p>

      {/* Steps List */}
      <div className="space-y-4 text-left">
        {steps.map((step, idx) => {
          const isDone = idx < activeStepIndex;
          const isCurrent = idx === activeStepIndex;

          return (
            <div
              key={step.id}
              className={`flex items-center justify-between p-3.5 rounded-xl border transition-all duration-300 ${
                isCurrent
                  ? 'bg-brand-50/80 dark:bg-brand-950/40 border-brand-300 dark:border-brand-700 shadow-sm'
                  : isDone
                  ? 'bg-slate-50/50 dark:bg-slate-900/40 border-emerald-200/60 dark:border-emerald-900/60'
                  : 'bg-transparent border-slate-100 dark:border-slate-800 opacity-40'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div
                  className={`p-2 rounded-lg ${
                    isDone
                      ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-100/60 dark:bg-emerald-950/60'
                      : isCurrent
                      ? 'text-brand-600 dark:text-brand-400 bg-brand-100 dark:bg-brand-900/60'
                      : 'text-slate-400 bg-slate-100 dark:bg-slate-800'
                  }`}
                >
                  {step.icon}
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                    {step.title}
                  </h4>
                  <span className="text-xs text-slate-400 font-medium">
                    {step.agent}
                  </span>
                </div>
              </div>

              <div>
                {isDone && <CheckCircle2 className="w-5 h-5 text-emerald-500 animate-scaleIn" />}
                {isCurrent && <Loader2 className="w-5 h-5 text-brand-600 dark:text-brand-400 animate-spin" />}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
