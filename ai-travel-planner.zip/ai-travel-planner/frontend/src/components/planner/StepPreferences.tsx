import React from 'react';
import { MapPin, Calendar, Users, DollarSign, Sparkles, Utensils, BedDouble, Train, HeartHandshake } from 'lucide-react';
import { CreateTripPayload } from '../../services/tripService';

interface StepPreferencesProps {
  formData: CreateTripPayload;
  onChange: (data: Partial<CreateTripPayload>) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const POPULAR_DESTINATIONS = [
  'Hyderabad', 'Paris', 'Tokyo', 'New York', 'Rome', 'London', 'Bali', 'Dubai', 'Barcelona', 'Singapore', 'Jaipur'
];

const INTEREST_OPTIONS = [
  { id: 'historical', label: 'Historical Monuments', icon: '🏛️' },
  { id: 'museums', label: 'Art & Museums', icon: '🎨' },
  { id: 'food', label: 'Food & Culinary', icon: '🍜' },
  { id: 'nature', label: 'Nature & Parks', icon: '🌿' },
  { id: 'architecture', label: 'Architecture', icon: '🏰' },
  { id: 'shopping', label: 'Local Markets & Shopping', icon: '🛍️' },
  { id: 'adventure', label: 'Adventure & Outdoors', icon: '🧗' },
  { id: 'relaxation', label: 'Relaxation & Spa', icon: '🏖️' },
];

const FOOD_OPTIONS = [
  'Local Specialties', 'Hyderabadi Biryani', 'Vegetarian', 'Vegan', 'Street Food', 'Halal', 'Fine Dining', 'Bistro & Bakery'
];

const CURRENCY_OPTIONS = ['USD', 'INR', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'AED', 'SGD'];

export const StepPreferences: React.FC<StepPreferencesProps> = ({
  formData,
  onChange,
  onSubmit,
  isLoading,
}) => {
  const toggleInterest = (id: string) => {
    const current = formData.preferences?.interests || [];
    const updated = current.includes(id) ? current.filter((x) => x !== id) : [...current, id];
    onChange({
      preferences: {
        ...formData.preferences!,
        interests: updated,
      },
    });
  };

  const toggleFoodPref = (food: string) => {
    const current = formData.preferences?.food_preferences || [];
    const updated = current.includes(food) ? current.filter((x) => x !== food) : [...current, food];
    onChange({
      preferences: {
        ...formData.preferences!,
        food_preferences: updated,
      },
    });
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. Destination & Dates Card */}
      <div className="glass-card p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="p-2 rounded-xl bg-brand-100 dark:bg-brand-950 text-brand-600 dark:text-brand-400">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Destination & Travel Window</h3>
            <p className="text-xs text-slate-500">Where are you heading and when?</p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
            Target Destination
          </label>
          <input
            type="text"
            required
            value={formData.destination}
            onChange={(e) => onChange({ destination: e.target.value })}
            placeholder="e.g. Hyderabad, Paris, Tokyo, New York"
            className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
          />

          {/* Quick Destination Chips */}
          <div className="flex flex-wrap gap-2 mt-3">
            {POPULAR_DESTINATIONS.map((dest) => (
              <button
                key={dest}
                type="button"
                onClick={() => onChange({ destination: dest })}
                className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-colors ${
                  formData.destination.toLowerCase() === dest.toLowerCase()
                    ? 'bg-brand-600 text-white border-brand-600 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-brand-500'
                }`}
              >
                {dest}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Start Date
            </label>
            <div className="relative">
              <input
                type="date"
                required
                value={formData.start_date}
                onChange={(e) => onChange({ start_date: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              End Date
            </label>
            <div className="relative">
              <input
                type="date"
                required
                value={formData.end_date}
                onChange={(e) => onChange({ end_date: e.target.value })}
                className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 2. Travelers, Budget & Currency */}
      <div className="glass-card p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Budget & Group Size</h3>
            <p className="text-xs text-slate-500">Define budget constraints for financial optimization</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Travelers
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={formData.travelers}
              onChange={(e) => onChange({ travelers: parseInt(e.target.value) || 1 })}
              className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Total Budget
            </label>
            <input
              type="number"
              min={100}
              step={500}
              value={formData.budget}
              onChange={(e) => onChange({ budget: parseFloat(e.target.value) || 1000 })}
              className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Currency
            </label>
            <select
              value={formData.currency}
              onChange={(e) => onChange({ currency: e.target.value })}
              className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
            >
              {CURRENCY_OPTIONS.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
            Travel Style
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { id: 'balanced', label: 'Balanced', desc: 'Mix of comfort & sights' },
              { id: 'budget', label: 'Budget / Backpacker', desc: 'Max savings & hostels' },
              { id: 'luxury', label: 'Luxury & Premium', desc: '5-star & fine dining' },
              { id: 'cultural', label: 'Cultural Deep-Dive', desc: 'Heritage & museums' },
            ].map((style) => (
              <button
                key={style.id}
                type="button"
                onClick={() => onChange({ travel_style: style.id })}
                className={`p-3 rounded-xl border text-left transition-all ${
                  formData.travel_style === style.id
                    ? 'border-brand-500 bg-brand-50/70 dark:bg-brand-950/50 shadow-sm ring-1 ring-brand-500'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="font-semibold text-sm text-slate-900 dark:text-white">{style.label}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{style.desc}</div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3. Interests & Food Preferences */}
      <div className="glass-card p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Interests & Preferences</h3>
            <p className="text-xs text-slate-500">Tailor activities and dining to what you love</p>
          </div>
        </div>

        {/* Interests */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-3">
            Select Your Interests
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {INTEREST_OPTIONS.map((item) => {
              const selected = formData.preferences?.interests.includes(item.id);
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => toggleInterest(item.id)}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 text-left transition-all ${
                    selected
                      ? 'border-brand-500 bg-brand-500 text-white shadow-sm font-semibold'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                  }`}
                >
                  <span className="text-lg">{item.icon}</span>
                  <span className="text-xs font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Food Preferences */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-3">
            Food & Dining Preferences
          </label>
          <div className="flex flex-wrap gap-2">
            {FOOD_OPTIONS.map((food) => {
              const selected = formData.preferences?.food_preferences.includes(food);
              return (
                <button
                  key={food}
                  type="button"
                  onClick={() => toggleFoodPref(food)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-colors ${
                    selected
                      ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-purple-400'
                  }`}
                >
                  {food}
                </button>
              );
            })}
          </div>
        </div>

        {/* Accommodation & Transportation */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Accommodation Type
            </label>
            <select
              value={formData.preferences?.accommodation_preference}
              onChange={(e) =>
                onChange({
                  preferences: { ...formData.preferences!, accommodation_preference: e.target.value },
                })
              }
              className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
            >
              <option value="hotel">Standard Hotel (3-4 Star)</option>
              <option value="luxury">Luxury Heritage / 5-Star Resort</option>
              <option value="hostel">Budget Boutique / Hostel</option>
              <option value="apartment">Serviced Vacation Apartment</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-2">
              Primary Transportation
            </label>
            <select
              value={formData.preferences?.transportation_preference}
              onChange={(e) =>
                onChange({
                  preferences: { ...formData.preferences!, transportation_preference: e.target.value },
                })
              }
              className="w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 font-medium text-slate-900 dark:text-white"
            >
              <option value="metro">Public Transit & Metro (Recommended)</option>
              <option value="cab">Cab / Uber / Taxi</option>
              <option value="rental_car">Rental Car</option>
              <option value="walking">Walking & Pedestrian</option>
            </select>
          </div>
        </div>
      </div>

      {/* Submit CTA Button */}
      <div className="flex justify-end pt-4">
        <button
          type="button"
          disabled={isLoading || !formData.destination.trim()}
          onClick={onSubmit}
          className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-brand-600 to-sky-500 text-white font-bold text-base shadow-lg shadow-brand-500/25 hover:shadow-brand-500/40 hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none transition-all flex items-center justify-center gap-2.5"
        >
          <Sparkles className="w-5 h-5" />
          <span>Generate AI Itinerary</span>
        </button>
      </div>
    </div>
  );
};
