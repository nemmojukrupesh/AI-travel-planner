import React from 'react';
import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4 space-y-4">
      <div className="w-16 h-16 rounded-2xl bg-brand-100 dark:bg-brand-950 text-brand-600 dark:text-brand-400 flex items-center justify-center">
        <Compass className="w-8 h-8" />
      </div>
      <h1 className="text-4xl font-black text-slate-900 dark:text-white">404</h1>
      <p className="text-sm text-slate-500 max-w-sm">
        We couldn't find the page or travel route you were looking for.
      </p>
      <Link
        to="/"
        className="px-6 py-3 rounded-xl bg-brand-600 text-white font-bold text-sm shadow-md shadow-brand-500/20 hover:bg-brand-500 transition-colors"
      >
        Return Home
      </Link>
    </div>
  );
};
