import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Compass,
  PlusCircle,
  Search,
  Calendar,
  Users,
  DollarSign,
  Copy,
  Trash2,
  ExternalLink,
  Download,
  MapPin,
  Sparkles
} from 'lucide-react';
import { tripService } from '../services/tripService';
import { exportService } from '../services/exportService';
import { Trip } from '../types';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatCurrency, formatDate } from '../utils/formatters';

export const SavedTripsPage: React.FC = () => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const fetchTrips = async () => {
    try {
      const data = await tripService.getTrips();
      setTrips(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTrips();
  }, []);

  const handleDelete = async (tripId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this travel plan?')) {
      try {
        await tripService.deleteTrip(tripId);
        setTrips((prev) => prev.filter((t) => t.id !== tripId));
      } catch (err) {
        alert('Failed to delete trip.');
      }
    }
  };

  const handleDuplicate = async (tripId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      const duplicated = await tripService.duplicateTrip(tripId);
      setTrips((prev) => [duplicated, ...prev]);
    } catch (err) {
      alert('Failed to duplicate trip.');
    }
  };

  const filteredTrips = trips.filter((t) =>
    t.destination.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white">
            Saved Travel Plans
          </h1>
          <p className="text-sm text-slate-500">Manage, export, and review your AI itineraries</p>
        </div>

        <Link
          to="/planner"
          className="px-5 py-3 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-sm shadow-md shadow-brand-500/20 transition-all hover:scale-105 flex items-center gap-2 self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Plan New Journey</span>
        </Link>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by destination (e.g. Hyderabad, Paris)..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-500"
        />
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
      </div>

      {/* Loading state */}
      {isLoading ? (
        <div className="py-20">
          <LoadingSpinner text="Loading saved trips..." />
        </div>
      ) : filteredTrips.length === 0 ? (
        /* Empty State */
        <div className="glass-card p-12 text-center max-w-md mx-auto space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400 flex items-center justify-center mx-auto">
            <Compass className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-slate-200">
            {searchQuery ? 'No trips matched your search' : 'No saved trips yet'}
          </h3>
          <p className="text-xs text-slate-500">
            Create your first AI itinerary with our multi-agent assistant to see it here!
          </p>
          <Link
            to="/planner"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-brand-600 text-white font-semibold text-xs shadow-md shadow-brand-500/20 hover:bg-brand-500 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Itinerary</span>
          </Link>
        </div>
      ) : (
        /* Trips Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTrips.map((t) => (
            <div
              key={t.id}
              onClick={() => navigate(`/trips/${t.id}`)}
              className="glass-card-hover p-6 cursor-pointer space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-extrabold text-lg">
                    <MapPin className="w-5 h-5 shrink-0" />
                    <span className="truncate">{t.destination}</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                    {t.duration_days} Days
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {formatDate(t.start_date)} – {formatDate(t.end_date)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {t.travelers} {t.travelers === 1 ? 'Traveler' : 'Travelers'} · {t.travel_style}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-200">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Budget: {formatCurrency(t.budget, t.currency || 'USD')}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
                <span className="text-brand-600 dark:text-brand-400 font-bold flex items-center gap-1 group-hover:underline">
                  View Plan <ExternalLink className="w-3.5 h-3.5" />
                </span>

                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={(e) => handleDuplicate(t.id, e)}
                    title="Duplicate Trip"
                    className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      exportService.downloadPdf(t.id, `itinerary_${t.destination.toLowerCase()}`);
                    }}
                    title="Export PDF"
                    className="p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => handleDelete(t.id, e)}
                    title="Delete Trip"
                    className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
