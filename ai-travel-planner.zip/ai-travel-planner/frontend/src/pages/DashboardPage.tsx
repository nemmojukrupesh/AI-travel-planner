import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Sparkles,
  MapPin,
  Calendar,
  Users,
  DollarSign,
  Download,
  FileText,
  MessageSquare,
  RefreshCw,
  TrendingDown,
  BedDouble,
  ShieldCheck,
  ChevronRight,
  Share2,
  Check,
  Layers
} from 'lucide-react';
import { tripService } from '../services/tripService';
import { exportService } from '../services/exportService';
import { Trip, TripItinerary, ItineraryVersion } from '../types';
import { DayScheduleCard } from '../components/itinerary/DayScheduleCard';
import { WeatherOverviewCard } from '../components/itinerary/WeatherCard';
import { BudgetOverview } from '../components/itinerary/BudgetOverview';
import { MapView } from '../components/itinerary/MapView';
import { SafetyAndTipsCard } from '../components/itinerary/SafetyAndTipsCard';
import { PackingListCard } from '../components/itinerary/PackingListCard';
import { ChatDrawer } from '../components/chat/ChatDrawer';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { formatCurrency, formatDate } from '../utils/formatters';

export const DashboardPage: React.FC = () => {
  const { tripId } = useParams<{ tripId: string }>();

  const [trip, setTrip] = useState<Trip | null>(null);
  const [itinerary, setItinerary] = useState<TripItinerary | null>(null);
  const [versions, setVersions] = useState<ItineraryVersion[]>([]);
  const [currentVersion, setCurrentVersion] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const loadTripData = async () => {
    if (!tripId) return;
    try {
      const tripData = await tripService.getTrip(tripId);
      setTrip(tripData);

      if (tripData.itineraries && tripData.itineraries.length > 0) {
        setVersions(tripData.itineraries);
        const active = tripData.itineraries.find((i) => i.is_active) || tripData.itineraries[0];
        setItinerary(active.itinerary_data);
        setCurrentVersion(active.version);
      } else if (tripData.latest_itinerary) {
        setItinerary(tripData.latest_itinerary);
        setCurrentVersion(tripData.latest_version || 1);
      }
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Failed to load itinerary.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTripData();
  }, [tripId]);

  const handleExportPdf = async () => {
    if (!tripId || !trip) return;
    setIsExportingPdf(true);
    try {
      await exportService.downloadPdf(tripId, `itinerary_${trip.destination.toLowerCase()}`);
    } catch (e) {
      // Fallback open direct
      window.open(exportService.getExportPdfUrl(tripId), '_blank');
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handleExportJson = async () => {
    if (!tripId || !trip) return;
    try {
      await exportService.downloadJson(tripId, `itinerary_${trip.destination.toLowerCase()}`);
    } catch (e) {
      window.open(exportService.getExportJsonUrl(tripId), '_blank');
    }
  };

  const handleOptimizeBudget = async () => {
    if (!tripId) return;
    setIsOptimizing(true);
    try {
      await tripService.optimizeBudget(tripId);
      await loadTripData();
    } catch (e) {
      alert('Could not optimize budget.');
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (isLoading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <LoadingSpinner size="lg" text="Loading AI Travel Dashboard..." />
      </div>
    );
  }

  if (error || !trip || !itinerary) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">
          {error || 'Itinerary not found'}
        </h2>
        <Link
          to="/planner"
          className="inline-block px-6 py-3 rounded-xl bg-brand-600 text-white font-bold text-sm"
        >
          Create New Trip
        </Link>
      </div>
    );
  }

  const currency = trip.currency || 'USD';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn pb-24">
      {/* 1. Trip Header Banner */}
      <div className="glass-card p-6 sm:p-8 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-3xl space-y-6 relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-400 px-3 py-1 rounded-full bg-brand-500/20 border border-brand-400/30">
                AI Itinerary · Version {currentVersion}
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white flex items-center gap-3">
              <MapPin className="w-8 h-8 text-brand-400 shrink-0" />
              {trip.destination}
            </h1>
            <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-slate-300 pt-1">
              <span className="flex items-center gap-1.5 font-medium">
                <Calendar className="w-4 h-4 text-brand-400" />
                {formatDate(trip.start_date)} – {formatDate(trip.end_date)} ({trip.duration_days} Days)
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 font-medium">
                <Users className="w-4 h-4 text-brand-400" />
                {trip.travelers} {trip.travelers === 1 ? 'Traveler' : 'Travelers'}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1.5 font-bold text-emerald-400">
                <DollarSign className="w-4 h-4" />
                Budget: {formatCurrency(trip.budget, currency)}
              </span>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* AI Chat Assistant Toggle */}
            <button
              onClick={() => setIsChatOpen(true)}
              className="px-4 py-3 rounded-xl bg-gradient-to-r from-brand-500 to-sky-400 text-white font-bold text-xs sm:text-sm shadow-md shadow-brand-500/25 hover:scale-105 transition-all flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Modify with AI Chat</span>
            </button>

            {/* Export PDF */}
            <button
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="px-3.5 py-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white font-semibold text-xs transition-all flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>{isExportingPdf ? 'Exporting...' : 'Export PDF'}</span>
            </button>

            {/* Export JSON */}
            <button
              onClick={handleExportJson}
              className="px-3.5 py-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white font-semibold text-xs transition-all flex items-center gap-1.5"
            >
              <FileText className="w-4 h-4" />
              <span>JSON</span>
            </button>

            {/* Share Link */}
            <button
              onClick={handleShare}
              className="p-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-white transition-all"
              title="Share Itinerary Link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* 2. Hotel & Accommodation Summary Card */}
      {itinerary.hotel && (
        <div className="glass-card p-6 border-l-4 border-l-purple-500 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
                <BedDouble className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-purple-600 dark:text-purple-400">
                  Recommended Accommodation
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">{itinerary.hotel.name}</h3>
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400">Total Stay ({Math.max(1, trip.duration_days - 1)} Nights)</span>
              <div className="text-base font-extrabold text-slate-900 dark:text-white">
                {formatCurrency(itinerary.hotel.total_cost, currency)}
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">{itinerary.hotel.why_recommended}</p>
          <div className="flex flex-wrap gap-2 pt-1">
            {itinerary.hotel.amenities.map((amenity, idx) => (
              <span
                key={idx}
                className="text-[11px] px-2.5 py-0.5 rounded-md bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 font-medium"
              >
                ✓ {amenity}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* 3. Weather Forecast Card */}
      <WeatherOverviewCard days={itinerary.days} />

      {/* 4. Day-by-Day Schedule Breakdown */}
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">
            Daily Itinerary Timeline
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            {itinerary.days.length} Days Planned
          </span>
        </div>

        <div className="space-y-6">
          {itinerary.days.map((day) => (
            <DayScheduleCard key={day.day} dayPlan={day} currency={currency} />
          ))}
        </div>
      </div>

      {/* 5. Geographic Activity Map */}
      <MapView itinerary={itinerary} />

      {/* 6. Budget & Financial Optimizer Section */}
      <BudgetOverview
        breakdown={itinerary.budget_breakdown}
        onOptimizeBudget={handleOptimizeBudget}
        isOptimizing={isOptimizing}
      />

      {/* 7. Safety Tips & Local Etiquette */}
      <SafetyAndTipsCard
        safety={itinerary.safety_recommendations}
        localTips={itinerary.local_tips}
      />

      {/* 8. Smart Packing Checklist */}
      <PackingListCard suggestions={itinerary.packing_suggestions} />

      {/* 9. Conversational Chat Drawer */}
      <ChatDrawer
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
        tripId={trip.id}
        destination={trip.destination}
        currentVersion={currentVersion}
        versions={versions}
        onItineraryUpdated={loadTripData}
        currency={currency}
      />
    </div>
  );
};
