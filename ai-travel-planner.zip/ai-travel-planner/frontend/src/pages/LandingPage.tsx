import React from 'react';
import { Link } from 'react-router-dom';
import {
  Compass,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CloudSun,
  DollarSign,
  MapPin,
  Bot,
  Layers,
  ChevronRight,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  return (
    <div className="space-y-24 pb-20">
      {/* 1. Hero Section */}
      <section className="relative pt-16 sm:pt-24 pb-12 overflow-hidden text-center">
        {/* Background Glows */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-tr from-brand-500/20 to-sky-400/20 blur-[120px] rounded-full pointer-events-none -z-10" />

        <div className="max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
          {/* Top Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800 text-brand-700 dark:text-brand-300 text-xs font-bold uppercase tracking-wider shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Next-Gen Autonomous Multi-Agent Travel AI</span>
          </div>

          {/* Heading */}
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15]">
            Personalized Travel Itineraries, <br />
            <span className="bg-gradient-to-r from-brand-600 via-sky-500 to-indigo-500 bg-clip-text text-transparent">
              Engineered by AI Agents.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Create hyper-personalized, budget-aware, weather-aware, and route-optimized travel schedules in seconds. Modify any day in natural language with our grounded Travel Assistant.
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              to="/planner"
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-brand-600 hover:bg-brand-500 text-white font-bold text-base shadow-lg shadow-brand-500/25 transition-all hover:scale-105 flex items-center justify-center gap-2"
            >
              <span>Plan My Trip with AI</span>
              <ArrowRight className="w-5 h-5" />
            </Link>

            <Link
              to="/saved"
              className="w-full sm:w-auto px-6 py-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-white/60 dark:bg-slate-900/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-base transition-all"
            >
              Browse Sample Itineraries
            </Link>
          </div>
        </div>
      </section>

      {/* 2. Feature Highlights (Multi-Agent System) */}
      <section id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-3">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Specialized Multi-Agent AI Architecture
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            Eight coordinated agents collaborate to generate, validate, and optimize every minute of your trip.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              title: 'Destination Agent',
              desc: 'Analyzes city culture, neighborhoods, safety profiles, and cultural etiquette.',
              icon: <MapPin className="w-6 h-6 text-brand-500" />,
              badge: 'RAG Grounded',
            },
            {
              title: 'Weather Agent',
              desc: 'Retrieves live Open-Meteo forecasts and swaps outdoor tours for museums in rain.',
              icon: <CloudSun className="w-6 h-6 text-amber-500" />,
              badge: 'Weather-Aware',
            },
            {
              title: 'Route Optimizer',
              desc: 'Groups attractions using geographic clustering and keeps transit times under 30 mins.',
              icon: <Compass className="w-6 h-6 text-emerald-500" />,
              badge: 'TSP Clustering',
            },
            {
              title: 'Budget Agent',
              desc: 'Tracks expenses across hotels, food, and activities, detecting and fixing budget overruns.',
              icon: <DollarSign className="w-6 h-6 text-purple-500" />,
              badge: 'Financial Optimizer',
            },
          ].map((feat, idx) => (
            <div key={idx} className="glass-card p-6 space-y-3 hover:border-brand-500/50 transition-all">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-xl bg-slate-100 dark:bg-slate-800">
                  {feat.icon}
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-brand-50 dark:bg-brand-950 text-brand-600 dark:text-brand-400 border border-brand-200 dark:border-brand-800">
                  {feat.badge}
                </span>
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">{feat.title}</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{feat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Interactive Example Showcase */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="glass-card p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white rounded-3xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-brand-400">Featured Sample Plan</span>
              <h3 className="text-2xl font-black text-white">3 Days in Historic Hyderabad</h3>
            </div>
            <div className="flex items-center gap-2 text-xs bg-white/10 px-3.5 py-1.5 rounded-xl">
              <span className="text-slate-300">Budget:</span>
              <span className="font-extrabold text-brand-300">₹15,000 INR (2 Travelers)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <span className="text-xs font-extrabold text-amber-400">DAY 1 · Historic Heart</span>
              <h4 className="text-sm font-bold text-white">Charminar & Chowmahalla</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Explore the 16th-century Charminar, shop lacquer bangles at Laad Bazaar, followed by Irani Chai at Nimrah.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <span className="text-xs font-extrabold text-sky-400">DAY 2 · Medieval Marvels</span>
              <h4 className="text-sm font-bold text-white">Golconda Fort & Tombs</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Marvel at acoustic architecture at Golconda Fort, Qutb Shahi Tombs, and legendary Mutton Dum Biryani.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <span className="text-xs font-extrabold text-purple-400">DAY 3 · Heritage & Art</span>
              <h4 className="text-sm font-bold text-white">Salar Jung & Hussain Sagar</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                View the Veiled Rebecca at Salar Jung Museum, take a sunset boat ride to Buddha statue at Hussain Sagar.
              </p>
            </div>
          </div>

          <div className="pt-2 text-center">
            <Link
              to="/planner"
              className="inline-flex items-center gap-2 text-xs font-bold text-brand-400 hover:text-brand-300 transition-colors"
            >
              <span>Generate your custom itinerary now</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* 4. FAQ Accordion */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 space-y-8">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Frequently Asked Questions</h2>
          <p className="text-xs text-slate-500">Everything you need to know about VoyageAI</p>
        </div>

        <div className="space-y-3">
          {[
            {
              q: 'How does the AI Multi-Agent system work?',
              a: 'Instead of relying on a single generic prompt, VoyageAI orchestrates 8 specialized agents. The Destination Agent grounds the plan with verified RAG knowledge, the Weather Agent checks real-time forecasts, the Route Optimizer uses geographic TSP heuristics to order stops, and the Budget Agent validates all expenses.',
            },
            {
              q: 'Can I customize the itinerary using natural language chat?',
              a: 'Yes! The Travel Assistant Agent allows you to request changes like "Make Day 2 cheaper", "Add more historical places", or "Remove the museum". It performs delta updates and creates versioned snapshots so you can undo changes at any time.',
            },
            {
              q: 'Can I export my travel itinerary as a PDF or JSON?',
              a: 'Absolutely. You can export clean, print-ready PDF itineraries containing your schedule, hotel bookings, budget breakdown, and travel tips, as well as JSON files for programmatic use.',
            },
          ].map((item, idx) => (
            <div key={idx} className="glass-card p-5 space-y-2">
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-brand-500 shrink-0" />
                {item.q}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed pl-6">{item.a}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
