import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, AlertCircle } from 'lucide-react';
import { StepPreferences } from '../components/planner/StepPreferences';
import { GenerationProgress } from '../components/planner/GenerationProgress';
import { tripService, CreateTripPayload } from '../services/tripService';

export const PlannerPage: React.FC = () => {
  const navigate = useNavigate();

  // Compute default dates (tomorrow to 3 days later)
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const threeDaysLater = new Date();
  threeDaysLater.setDate(tomorrow.getDate() + 3);

  const [formData, setFormData] = useState<CreateTripPayload>({
    destination: 'Hyderabad',
    start_date: tomorrow.toISOString().split('T')[0],
    end_date: threeDaysLater.toISOString().split('T')[0],
    travelers: 2,
    budget: 15000,
    currency: 'INR',
    travel_style: 'balanced',
    preferences: {
      interests: ['historical', 'food'],
      food_preferences: ['Local Specialties', 'Hyderabadi Biryani'],
      accommodation_preference: 'hotel',
      transportation_preference: 'metro',
      special_requirements: '',
    },
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleFormChange = (updates: Partial<CreateTripPayload>) => {
    setFormData((prev) => ({
      ...prev,
      ...updates,
    }));
  };

  const handleGenerate = async () => {
    if (!formData.destination.trim()) {
      setErrorMessage('Please specify a valid destination.');
      return;
    }
    setErrorMessage('');
    setIsGenerating(true);

    try {
      // 1. Create Trip Record
      const createdTrip = await tripService.createTrip(formData);

      // 2. Generate AI Multi-Agent Itinerary
      await tripService.generateItinerary(createdTrip.id);

      // 3. Small timeout for smooth UX transition
      setTimeout(() => {
        navigate(`/trips/${createdTrip.id}`);
      }, 1200);
    } catch (err: any) {
      setIsGenerating(false);
      setErrorMessage(
        err.response?.data?.detail || 'Failed to generate itinerary. Please verify your inputs and try again.'
      );
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 animate-fadeIn">
      {/* Header Banner */}
      {!isGenerating && (
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800 text-brand-700 dark:text-brand-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>AI Trip Planner Wizard</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
            Where would you like to travel?
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xl mx-auto">
            Specify your destination, dates, budget, and travel interests. Our multi-agent system will generate your complete day-by-day plan.
          </p>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Render Wizard or Progress Screen */}
      {isGenerating ? (
        <GenerationProgress destination={formData.destination} />
      ) : (
        <StepPreferences
          formData={formData}
          onChange={handleFormChange}
          onSubmit={handleGenerate}
          isLoading={isGenerating}
        />
      )}
    </div>
  );
};
