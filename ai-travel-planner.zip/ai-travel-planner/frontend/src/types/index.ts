export interface User {
  id: number;
  name: string;
  email: string;
  created_at: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export interface GeoLocation {
  name: string;
  latitude: number;
  longitude: number;
}

export interface TravelTransit {
  from_name: string;
  to_name: string;
  mode: string;
  duration_minutes: number;
  distance_km: number;
  estimated_cost: number;
}

export interface ActivityItem {
  id?: string;
  name: string;
  category: string;
  description: string;
  start_time: string;
  duration_minutes: number;
  estimated_cost: number;
  location: GeoLocation;
  is_indoor: boolean;
  reason: string;
  booking_required: boolean;
  rating: number;
  travel_from_prev?: TravelTransit | null;
}

export interface MealItem {
  meal_type: 'breakfast' | 'lunch' | 'dinner' | string;
  restaurant_name: string;
  cuisine: string;
  estimated_cost: number;
  location: GeoLocation;
  recommended_dish: string;
  dietary_notes: string;
  reason: string;
}

export interface TransportationItem {
  from_location: string;
  to_location: string;
  mode: string;
  duration_minutes: number;
  distance_km: number;
  estimated_cost: number;
  notes: string;
}

export interface HotelSuggestion {
  name: string;
  category: string;
  estimated_cost_per_night: number;
  total_cost: number;
  location: GeoLocation;
  rating: number;
  amenities: string[];
  why_recommended: string;
}

export interface DayWeather {
  temperature_c: number;
  condition: string;
  rain_probability_pct: number;
  is_favorable_for_outdoor: boolean;
  advisory: string;
}

export interface DayPlan {
  day: number;
  date: string;
  theme: string;
  weather: DayWeather;
  morning_activities: ActivityItem[];
  afternoon_activities: ActivityItem[];
  evening_activities: ActivityItem[];
  meals: MealItem[];
  transportation: TransportationItem[];
  estimated_day_cost: number;
  day_tips: string[];
}

export interface BudgetBreakdown {
  accommodation: number;
  food: number;
  transport: number;
  activities: number;
  miscellaneous: number;
  total_estimated: number;
  user_budget: number;
  currency: string;
  is_over_budget: boolean;
  overrun_amount: number;
  savings_suggestions: string[];
}

export interface TripSummary {
  destination: string;
  duration_days: number;
  travelers: number;
  budget: number;
  currency: string;
  estimated_total_cost: number;
  travel_style: string;
  highlights: string[];
}

export interface TripItinerary {
  trip_summary: TripSummary;
  hotel: HotelSuggestion;
  days: DayPlan[];
  budget_breakdown: BudgetBreakdown;
  packing_suggestions: string[];
  safety_recommendations: string[];
  local_tips: string[];
  alternative_activities: ActivityItem[];
}

export interface TripPreferences {
  interests: string[];
  food_preferences: string[];
  accommodation_preference: string;
  transportation_preference: string;
  special_requirements?: string;
}

export interface ItineraryVersion {
  id: string;
  trip_id: string;
  version: number;
  itinerary_data: TripItinerary;
  estimated_cost: number;
  change_summary?: string;
  is_active: boolean;
  created_at: string;
}

export interface Trip {
  id: string;
  user_id?: number | null;
  destination: string;
  start_date: string;
  end_date: string;
  duration_days: number;
  travelers: number;
  budget: number;
  currency: string;
  travel_style: string;
  created_at: string;
  latest_itinerary?: TripItinerary | null;
  latest_version?: number | null;
  preferences?: TripPreferences | null;
  itineraries?: ItineraryVersion[];
}

export interface ChatMessage {
  id?: number;
  role: 'user' | 'assistant';
  message: string;
  created_at?: string;
}

export interface ChatResponse {
  reply: string;
  updated_itinerary?: TripItinerary | null;
  version: number;
  changes_made: string[];
}

export interface WeatherForecastDay {
  date: string;
  temperature_max_c: number;
  temperature_min_c: number;
  condition: string;
  precipitation_probability: number;
  is_outdoor_friendly: boolean;
  summary: string;
}

export interface WeatherData {
  destination: string;
  latitude: number;
  longitude: number;
  current_temp_c: number;
  condition: string;
  daily_forecasts: WeatherForecastDay[];
}
