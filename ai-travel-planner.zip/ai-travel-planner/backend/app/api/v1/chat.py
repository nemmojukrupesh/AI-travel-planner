import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_optional_current_user
from app.models.user import User
from app.models.trip import Trip
from app.models.itinerary import Itinerary
from app.models.conversation import Conversation
from app.schemas.chat import ChatRequest, ChatResponse, ConversationMessageOut
from app.schemas.itinerary import TripItinerary
from app.services.agents.travel_assistant_agent import travel_assistant_agent
from app.core.logging import logger

router = APIRouter(prefix="/trips/{trip_id}", tags=["AI Travel Assistant Chat"])

@router.post("/chat", response_model=ChatResponse)
async def chat_with_assistant(
    trip_id: str,
    chat_in: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_optional_current_user)
):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    if not trip.itineraries:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Please generate an initial itinerary first before requesting modifications."
        )

    # Find active itinerary
    active_it = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
    current_itinerary = TripItinerary(**json.loads(active_it.itinerary_json))

    # Save user conversation
    user_conv = Conversation(trip_id=trip.id, role="user", message=chat_in.message)
    db.add(user_conv)

    # Process conversational change with TravelAssistantAgent
    agent_context = {
        "user_message": chat_in.message,
        "current_itinerary": current_itinerary,
        "destination": trip.destination
    }
    result_context = await travel_assistant_agent.process(agent_context)

    reply_text = result_context["reply"]
    updated_itinerary: TripItinerary = result_context["updated_itinerary"]
    changes_made = result_context.get("changes_made", [])

    # Save new active itinerary version
    for it in trip.itineraries:
        it.is_active = False

    new_version_num = (max([i.version for i in trip.itineraries], default=0)) + 1
    new_version_record = Itinerary(
        trip_id=trip.id,
        version=new_version_num,
        itinerary_json=updated_itinerary.model_dump_json(),
        estimated_cost=updated_itinerary.trip_summary.estimated_total_cost,
        change_summary="; ".join(changes_made) if changes_made else "Conversational update",
        is_active=True
    )
    db.add(new_version_record)

    # Save assistant conversation
    assistant_conv = Conversation(trip_id=trip.id, role="assistant", message=reply_text)
    db.add(assistant_conv)

    db.commit()

    return ChatResponse(
        reply=reply_text,
        updated_itinerary=updated_itinerary,
        version=new_version_num,
        changes_made=changes_made
    )

@router.get("/conversation", response_model=List[ConversationMessageOut])
def get_conversation_history(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    messages = db.query(Conversation).filter(Conversation.trip_id == trip_id).order_by(Conversation.created_at.asc()).all()
    return [ConversationMessageOut.model_validate(m) for m in messages]
