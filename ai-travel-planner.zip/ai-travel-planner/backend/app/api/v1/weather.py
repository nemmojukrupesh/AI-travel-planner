from fastapi import APIRouter, Query, HTTPException, status
from app.services.adapters.weather_adapter import weather_service
from app.schemas.weather import WeatherResponse, DailyForecast

router = APIRouter(prefix="/weather", tags=["Weather Intelligence"])

@router.get("", response_model=WeatherResponse)
async def get_weather(
    destination: str = Query(..., description="Destination city name, e.g. 'Hyderabad' or 'Paris'"),
    days: int = Query(7, ge=1, le=14, description="Forecast days")
):
    try:
        res = await weather_service.get_forecast(destination, days=days)
        return WeatherResponse(
            destination=res["destination"],
            latitude=res["latitude"],
            longitude=res["longitude"],
            current_temp_c=res["current_temp_c"],
            condition=res["condition"],
            daily_forecasts=[DailyForecast(**df) for df in res["daily_forecasts"]]
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve weather for {destination}: {str(e)}"
        )
