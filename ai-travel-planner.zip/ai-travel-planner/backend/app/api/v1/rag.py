from typing import Optional, List, Dict, Any
from pydantic import BaseModel
from fastapi import APIRouter, Query
from app.services.rag.retriever import rag_retriever
from app.services.rag.knowledge_base import TRAVEL_KNOWLEDGE_DOCUMENTS

router = APIRouter(prefix="/rag", tags=["RAG Travel Knowledge"])

class RAGQueryRequest(BaseModel):
    query: str
    destination: Optional[str] = None
    top_k: int = 3

class RAGSource(BaseModel):
    id: str
    title: str
    destination: str
    category: str

class RAGQueryResponse(BaseModel):
    query: str
    destination: Optional[str] = None
    grounded_answer_context: str
    sources: List[RAGSource]

@router.post("/query", response_model=RAGQueryResponse)
def query_travel_knowledge(request: RAGQueryRequest):
    data = rag_retriever.retrieve_context(
        query=request.query,
        destination=request.destination,
        top_k=request.top_k
    )
    return RAGQueryResponse(
        query=data["query"],
        destination=data["destination"],
        grounded_answer_context=data["context_text"],
        sources=[RAGSource(**s) for s in data["sources"]]
    )

@router.get("/destinations", response_model=List[str])
def get_supported_rag_destinations():
    dests = sorted(list(set(d["destination"] for d in TRAVEL_KNOWLEDGE_DOCUMENTS)))
    return dests
