from typing import Optional
from fastapi import APIRouter, Query
from app.services.adapters.places_adapter import places_service
from app.schemas.place import PlaceSearchResponse, PlaceItem

router = APIRouter(prefix="/places", tags=["Places & Attractions"])

@router.get("/search", response_model=PlaceSearchResponse)
async def search_places(
    destination: str = Query(..., description="Destination city name"),
    category: Optional[str] = Query(None, description="Category filter, e.g. 'historical', 'museum', 'nature'"),
    limit: int = Query(15, ge=1, le=50)
):
    places_raw = await places_service.search_places(destination=destination, category=category, limit=limit)
    items = [
        PlaceItem(
            name=p.get("name", "Attraction"),
            category=p.get("category", "sightseeing"),
            latitude=p.get("latitude", 0.0),
            longitude=p.get("longitude", 0.0),
            address=p.get("address", ""),
            rating=p.get("rating", 4.5),
            price_level=p.get("price_level", 2),
            is_indoor=p.get("is_indoor", False),
            opening_hours=p.get("opening_hours", "09:00 - 18:00"),
            description=p.get("description", "")
        )
        for p in places_raw
    ]
    return PlaceSearchResponse(
        destination=destination,
        total_results=len(items),
        places=items
    )

@router.get("/nearby", response_model=PlaceSearchResponse)
async def get_nearby_places(
    destination: str = Query(..., description="Destination city name"),
    limit: int = Query(10, ge=1, le=30)
):
    return await search_places(destination=destination, limit=limit)
