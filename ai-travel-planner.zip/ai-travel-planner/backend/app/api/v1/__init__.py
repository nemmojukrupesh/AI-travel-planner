from fastapi import APIRouter
from app.api.v1.auth import router as auth_router
from app.api.v1.trips import router as trips_router
from app.api.v1.chat import router as chat_router
from app.api.v1.weather import router as weather_router
from app.api.v1.places import router as places_router
from app.api.v1.budget import router as budget_router
from app.api.v1.rag import router as rag_router
from app.api.v1.export import router as export_router

api_v1_router = APIRouter(prefix="/api")

api_v1_router.include_router(auth_router)
api_v1_router.include_router(trips_router)
api_v1_router.include_router(chat_router)
api_v1_router.include_router(weather_router)
api_v1_router.include_router(places_router)
api_v1_router.include_router(budget_router)
api_v1_router.include_router(rag_router)
api_v1_router.include_router(export_router)

__all__ = ["api_v1_router"]
