import json
from typing import List, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_optional_current_user
from app.models.user import User
from app.models.trip import Trip
from app.models.preference import Preference
from app.models.itinerary import Itinerary
from app.models.conversation import Conversation
from app.schemas.trip import TripCreate, TripUpdate, TripOut, TripDetailOut
from app.schemas.itinerary import TripItinerary, ItineraryVersionOut
from app.schemas.preference import PreferenceOut
from app.services.agents.orchestrator import orchestrator
from app.core.logging import logger

router = APIRouter(prefix="/trips", tags=["Trips & Itineraries"])

def _format_trip_out(trip: Trip) -> TripOut:
    latest_itin = None
    latest_ver = None
    if trip.itineraries:
        active_itin = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
        try:
            latest_itin = TripItinerary(**json.loads(active_itin.itinerary_json))
            latest_ver = active_itin.version
        except Exception as e:
            logger.error(f"Error deserializing itinerary json for trip {trip.id}: {e}")

    return TripOut(
        id=trip.id,
        user_id=trip.user_id,
        destination=trip.destination,
        start_date=trip.start_date,
        end_date=trip.end_date,
        duration_days=trip.duration_days,
        travelers=trip.travelers,
        budget=trip.budget,
        currency=trip.currency,
        travel_style=trip.travel_style,
        created_at=trip.created_at,
        latest_itinerary=latest_itin,
        latest_version=latest_ver
    )

@router.post("", response_model=TripOut, status_code=status.HTTP_201_CREATED)
def create_trip(
    trip_in: TripCreate,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_current_user)
):
    duration_days = max(1, (trip_in.end_date - trip_in.start_date).days + 1)
    
    trip = Trip(
        user_id=current_user.id if current_user else None,
        destination=trip_in.destination.strip(),
        start_date=trip_in.start_date,
        end_date=trip_in.end_date,
        duration_days=duration_days,
        travelers=trip_in.travelers,
        budget=trip_in.budget,
        currency=trip_in.currency.upper(),
        travel_style=trip_in.travel_style
    )
    db.add(trip)
    db.flush()

    if trip_in.preferences:
        pref = Preference(
            trip_id=trip.id,
            interests=json.dumps(trip_in.preferences.interests),
            food_preferences=json.dumps(trip_in.preferences.food_preferences),
            accommodation_preference=trip_in.preferences.accommodation_preference,
            transportation_preference=trip_in.preferences.transportation_preference,
            special_requirements=trip_in.preferences.special_requirements
        )
        db.add(pref)

    db.commit()
    db.refresh(trip)
    return _format_trip_out(trip)

@router.get("", response_model=List[TripOut])
def list_trips(
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_optional_current_user)
):
    query = db.query(Trip)
    if current_user:
        query = query.filter((Trip.user_id == current_user.id) | (Trip.user_id == None))
    trips = query.order_by(Trip.created_at.desc()).all()
    return [_format_trip_out(t) for t in trips]

@router.get("/{trip_id}", response_model=TripDetailOut)
def get_trip_detail(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    base_out = _format_trip_out(trip)

    pref_out = None
    if trip.preferences:
        pref_out = PreferenceOut(
            id=trip.preferences.id,
            trip_id=trip.preferences.trip_id,
            interests=json.loads(trip.preferences.interests or "[]"),
            food_preferences=json.loads(trip.preferences.food_preferences or "[]"),
            accommodation_preference=trip.preferences.accommodation_preference,
            transportation_preference=trip.preferences.transportation_preference,
            special_requirements=trip.preferences.special_requirements
        )

    itineraries_out = []
    for it in trip.itineraries:
        try:
            itineraries_out.append(
                ItineraryVersionOut(
                    id=it.id,
                    trip_id=it.trip_id,
                    version=it.version,
                    itinerary_data=TripItinerary(**json.loads(it.itinerary_json)),
                    estimated_cost=it.estimated_cost,
                    change_summary=it.change_summary,
                    is_active=it.is_active,
                    created_at=it.created_at
                )
            )
        except Exception as e:
            logger.error(f"Error parsing version {it.version}: {e}")

    return TripDetailOut(
        **base_out.model_dump(),
        preferences=pref_out,
        itineraries=itineraries_out
    )

@router.delete("/{trip_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_trip(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")
    db.delete(trip)
    db.commit()
    return None

@router.post("/{trip_id}/duplicate", response_model=TripOut)
def duplicate_trip(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    new_trip = Trip(
        user_id=trip.user_id,
        destination=f"{trip.destination} (Copy)",
        start_date=trip.start_date,
        end_date=trip.end_date,
        duration_days=trip.duration_days,
        travelers=trip.travelers,
        budget=trip.budget,
        currency=trip.currency,
        travel_style=trip.travel_style
    )
    db.add(new_trip)
    db.flush()

    if trip.preferences:
        new_pref = Preference(
            trip_id=new_trip.id,
            interests=trip.preferences.interests,
            food_preferences=trip.preferences.food_preferences,
            accommodation_preference=trip.preferences.accommodation_preference,
            transportation_preference=trip.preferences.transportation_preference,
            special_requirements=trip.preferences.special_requirements
        )
        db.add(new_pref)

    # Copy latest itinerary if present
    if trip.itineraries:
        active_itin = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
        new_itin = Itinerary(
            trip_id=new_trip.id,
            version=1,
            itinerary_json=active_itin.itinerary_json,
            estimated_cost=active_itin.estimated_cost,
            change_summary="Duplicated from original trip",
            is_active=True
        )
        db.add(new_itin)

    db.commit()
    db.refresh(new_trip)
    return _format_trip_out(new_trip)

@router.post("/{trip_id}/generate", response_model=TripItinerary)
async def generate_trip_itinerary(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    interests = []
    food_prefs = []
    acc_pref = "hotel"
    trans_pref = "public_transit"

    if trip.preferences:
        interests = json.loads(trip.preferences.interests or "[]")
        food_prefs = json.loads(trip.preferences.food_preferences or "[]")
        acc_pref = trip.preferences.accommodation_preference
        trans_pref = trip.preferences.transportation_preference

    trip_payload = {
        "destination": trip.destination,
        "start_date": str(trip.start_date),
        "end_date": str(trip.end_date),
        "duration_days": trip.duration_days,
        "travelers": trip.travelers,
        "budget": trip.budget,
        "currency": trip.currency,
        "travel_style": trip.travel_style,
        "interests": interests,
        "food_preferences": food_prefs,
        "accommodation_preference": acc_pref,
        "transportation_preference": trans_pref
    }

    # Execute Multi-Agent pipeline
    itinerary_obj = await orchestrator.plan_trip(trip_payload)

    # Save version
    # Set all existing to inactive
    for existing_it in trip.itineraries:
        existing_it.is_active = False

    next_version = (max([i.version for i in trip.itineraries], default=0)) + 1
    new_version_record = Itinerary(
        trip_id=trip.id,
        version=next_version,
        itinerary_json=itinerary_obj.model_dump_json(),
        estimated_cost=itinerary_obj.trip_summary.estimated_total_cost,
        change_summary="Initial AI Multi-Agent Generation",
        is_active=True
    )
    db.add(new_version_record)
    db.commit()

    return itinerary_obj

@router.post("/{trip_id}/regenerate", response_model=TripItinerary)
async def regenerate_trip_itinerary(trip_id: str, db: Session = Depends(get_db)):
    return await generate_trip_itinerary(trip_id, db)

@router.post("/{trip_id}/versions/{version_number}/restore", response_model=TripItinerary)
def restore_itinerary_version(trip_id: str, version_number: int, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip not found.")

    target_ver = next((i for i in trip.itineraries if i.version == version_number), None)
    if not target_ver:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Version {version_number} not found.")

    for it in trip.itineraries:
        it.is_active = (it.version == version_number)

    db.commit()
    return TripItinerary(**json.loads(target_ver.itinerary_json))
