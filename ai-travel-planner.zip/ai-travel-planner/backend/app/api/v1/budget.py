import json
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.models.trip import Trip
from app.models.itinerary import Itinerary
from app.schemas.budget import BudgetOptimizationResponse, BudgetSummaryResponse
from app.schemas.itinerary import TripItinerary
from app.services.optimizer.budget_optimizer import budget_optimizer

router = APIRouter(prefix="/trips/{trip_id}/budget", tags=["Budget & Optimization"])

@router.get("", response_model=BudgetSummaryResponse)
def get_trip_budget_breakdown(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip or not trip.itineraries:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip or itinerary not found.")

    active_itin = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
    itin_obj = TripItinerary(**json.loads(active_itin.itinerary_json))
    
    breakdown = budget_optimizer.calculate_total_breakdown(itin_obj, trip.travelers)
    total = max(1.0, breakdown.total_estimated)
    percentages = {
        "accommodation": round((breakdown.accommodation / total) * 100, 1),
        "food": round((breakdown.food / total) * 100, 1),
        "transport": round((breakdown.transport / total) * 100, 1),
        "activities": round((breakdown.activities / total) * 100, 1),
        "miscellaneous": round((breakdown.miscellaneous / total) * 100, 1)
    }

    return BudgetSummaryResponse(
        trip_id=trip_id,
        budget_breakdown=breakdown,
        category_percentages=percentages
    )

@router.post("/optimize", response_model=BudgetOptimizationResponse)
def optimize_trip_budget(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip or not trip.itineraries:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip or itinerary not found.")

    active_itin = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
    itin_obj = TripItinerary(**json.loads(active_itin.itinerary_json))

    optimized_obj, changes, orig_c, new_c = budget_optimizer.optimize_to_budget(itin_obj)

    # Save as new active version
    for it in trip.itineraries:
        it.is_active = False

    new_ver = (max([i.version for i in trip.itineraries], default=0)) + 1
    new_record = Itinerary(
        trip_id=trip.id,
        version=new_ver,
        itinerary_json=optimized_obj.model_dump_json(),
        estimated_cost=new_c,
        change_summary="Automatic Budget Optimization",
        is_active=True
    )
    db.add(new_record)
    db.commit()

    return BudgetOptimizationResponse(
        trip_id=trip.id,
        original_cost=orig_c,
        optimized_cost=new_c,
        user_budget=trip.budget,
        currency=trip.currency,
        savings=round(max(0.0, orig_c - new_c), 2),
        is_within_budget=(new_c <= trip.budget),
        changes_made=changes,
        optimized_itinerary=optimized_obj
    )
