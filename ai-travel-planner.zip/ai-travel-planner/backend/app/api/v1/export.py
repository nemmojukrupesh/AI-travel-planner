import json
import io
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse, Response, StreamingResponse
from sqlalchemy.orm import Session
from app.api.deps import get_db
from app.models.trip import Trip
from app.schemas.itinerary import TripItinerary

router = APIRouter(prefix="/trips/{trip_id}/export", tags=["Export"])

@router.get("/json")
def export_trip_json(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip or not trip.itineraries:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip or itinerary not found.")

    active_it = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
    data = json.loads(active_it.itinerary_json)
    
    headers = {
        "Content-Disposition": f"attachment; filename=itinerary_{trip.destination.lower().replace(' ', '_')}.json"
    }
    return JSONResponse(content=data, headers=headers)

@router.get("/pdf")
def export_trip_pdf(trip_id: str, db: Session = Depends(get_db)):
    trip = db.query(Trip).filter(Trip.id == trip_id).first()
    if not trip or not trip.itineraries:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Trip or itinerary not found.")

    active_it = next((i for i in trip.itineraries if i.is_active), trip.itineraries[0])
    itin = TripItinerary(**json.loads(active_it.itinerary_json))

    # Generate PDF using ReportLab
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            name="TitleStyle",
            parent=styles["Title"],
            fontSize=22,
            leading=26,
            textColor=colors.HexColor("#1e3a8a"),
            alignment=0
        )
        heading_style = ParagraphStyle(
            name="Heading2Style",
            parent=styles["Heading2"],
            fontSize=14,
            leading=18,
            textColor=colors.HexColor("#0284c7")
        )
        body_style = styles["BodyText"]

        story = []

        # Title
        story.append(Paragraph(f"AI Travel Plan: {itin.trip_summary.destination}", title_style))
        story.append(Paragraph(f"<b>Dates:</b> {trip.start_date} to {trip.end_date} ({itin.trip_summary.duration_days} Days) | <b>Travelers:</b> {itin.trip_summary.travelers} | <b>Budget:</b> {itin.trip_summary.currency} {itin.trip_summary.budget:,.2f}", body_style))
        story.append(Spacer(1, 12))

        # Hotel
        story.append(Paragraph("Accommodation", heading_style))
        story.append(Paragraph(f"<b>Hotel:</b> {itin.hotel.name} ({itin.hotel.category}) - Total: {itin.trip_summary.currency} {itin.hotel.total_cost:,.2f}", body_style))
        story.append(Spacer(1, 10))

        # Days
        for day in itin.days:
            story.append(Paragraph(f"Day {day.day}: {day.theme} ({day.date})", heading_style))
            story.append(Paragraph(f"<i>Weather: {day.weather.condition}, {day.weather.temperature_c}°C - {day.weather.advisory}</i>", body_style))
            story.append(Spacer(1, 6))

            # Morning
            if day.morning_activities:
                act = day.morning_activities[0]
                story.append(Paragraph(f"• <b>Morning ({act.start_time}):</b> {act.name} ({act.category.title()}) - {act.description}", body_style))
            # Afternoon
            if day.afternoon_activities:
                act = day.afternoon_activities[0]
                story.append(Paragraph(f"• <b>Afternoon ({act.start_time}):</b> {act.name} ({act.category.title()}) - {act.description}", body_style))
            # Evening
            if day.evening_activities:
                act = day.evening_activities[0]
                story.append(Paragraph(f"• <b>Evening ({act.start_time}):</b> {act.name} ({act.category.title()}) - {act.description}", body_style))

            # Dining
            if day.meals:
                meal_summary = " | ".join([f"{m.meal_type.title()}: {m.restaurant_name} ({m.recommended_dish})" for m in day.meals])
                story.append(Paragraph(f"• <b>Meals:</b> {meal_summary}", body_style))

            story.append(Spacer(1, 10))

        # Budget summary
        story.append(Paragraph("Budget & Estimated Expenses", heading_style))
        b = itin.budget_breakdown
        b_data = [
            ["Category", "Estimated Cost"],
            ["Accommodation", f"{b.currency} {b.accommodation:,.2f}"],
            ["Food & Dining", f"{b.currency} {b.food:,.2f}"],
            ["Local Transport", f"{b.currency} {b.transport:,.2f}"],
            ["Activities & Sightseeing", f"{b.currency} {b.activities:,.2f}"],
            ["Buffer & Misc", f"{b.currency} {b.miscellaneous:,.2f}"],
            ["Total Estimated", f"{b.currency} {b.total_estimated:,.2f}"]
        ]
        t = Table(b_data, colWidths=[200, 200])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#f1f5f9")),
            ('TEXTCOLOR', (0,0), (-1,0), colors.HexColor("#0f172a")),
            ('ALIGN', (0,0), (-1,-1), 'LEFT'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 4),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#cbd5e1")),
        ]))
        story.append(t)

        doc.build(story)
        buffer.seek(0)

        filename = f"itinerary_{trip.destination.lower().replace(' ', '_')}.pdf"
        return StreamingResponse(
            buffer,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        logger.error(f"Error generating PDF: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate PDF: {str(e)}"
        )
