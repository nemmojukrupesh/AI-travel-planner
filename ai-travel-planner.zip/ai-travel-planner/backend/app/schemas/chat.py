from pydantic import BaseModel, ConfigDict
from typing import List, Optional
from datetime import datetime
from app.schemas.itinerary import TripItinerary

class ChatRequest(BaseModel):
    message: str
    current_version: Optional[int] = None

class ChatResponse(BaseModel):
    reply: str
    updated_itinerary: Optional[TripItinerary] = None
    version: int
    changes_made: List[str] = []

class ConversationMessageOut(BaseModel):
    id: int
    trip_id: str
    role: str
    message: str
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
