from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime

class GeoLocation(BaseModel):
    name: str = ""
    latitude: float = 0.0
    longitude: float = 0.0

class TravelTransit(BaseModel):
    from_name: str = ""
    to_name: str = ""
    mode: str = "transit"  # metro, walk, cab, bus
    duration_minutes: int = 15
    distance_km: float = 2.0
    estimated_cost: float = 0.0

class ActivityItem(BaseModel):
    id: Optional[str] = None
    name: str
    category: str = "sightseeing"  # historical, nature, adventure, museum, food, shopping, entertainment
    description: str = ""
    start_time: str = "09:00"
    duration_minutes: int = 90
    estimated_cost: float = 0.0
    location: GeoLocation = Field(default_factory=GeoLocation)
    is_indoor: bool = False
    reason: str = ""
    booking_required: bool = False
    rating: float = 4.5
    travel_from_prev: Optional[TravelTransit] = None

class MealItem(BaseModel):
    meal_type: str = "lunch"  # breakfast, lunch, dinner
    restaurant_name: str
    cuisine: str = "Local"
    estimated_cost: float = 0.0
    location: GeoLocation = Field(default_factory=GeoLocation)
    recommended_dish: str = ""
    dietary_notes: str = ""
    reason: str = ""

class TransportationItem(BaseModel):
    from_location: str
    to_location: str
    mode: str = "metro"
    duration_minutes: int = 20
    distance_km: float = 5.0
    estimated_cost: float = 0.0
    notes: str = ""

class HotelSuggestion(BaseModel):
    name: str
    category: str = "Mid-range Hotel"
    estimated_cost_per_night: float = 0.0
    total_cost: float = 0.0
    location: GeoLocation = Field(default_factory=GeoLocation)
    rating: float = 4.3
    amenities: List[str] = []
    why_recommended: str = ""

class DayWeather(BaseModel):
    temperature_c: float = 25.0
    condition: str = "Sunny"
    rain_probability_pct: int = 10
    is_favorable_for_outdoor: bool = True
    advisory: str = "Great conditions for outdoor exploring."

class DayPlan(BaseModel):
    day: int
    date: str
    theme: str
    weather: DayWeather = Field(default_factory=DayWeather)
    morning_activities: List[ActivityItem] = []
    afternoon_activities: List[ActivityItem] = []
    evening_activities: List[ActivityItem] = []
    meals: List[MealItem] = []
    transportation: List[TransportationItem] = []
    estimated_day_cost: float = 0.0
    day_tips: List[str] = []

class BudgetBreakdown(BaseModel):
    accommodation: float = 0.0
    food: float = 0.0
    transport: float = 0.0
    activities: float = 0.0
    miscellaneous: float = 0.0
    total_estimated: float = 0.0
    user_budget: float = 0.0
    currency: str = "USD"
    is_over_budget: bool = False
    overrun_amount: float = 0.0
    savings_suggestions: List[str] = []

class TripSummary(BaseModel):
    destination: str
    duration_days: int
    travelers: int
    budget: float
    currency: str
    estimated_total_cost: float
    travel_style: str
    highlights: List[str] = []

class TripItinerary(BaseModel):
    trip_summary: TripSummary
    hotel: HotelSuggestion
    days: List[DayPlan]
    budget_breakdown: BudgetBreakdown
    packing_suggestions: List[str] = []
    safety_recommendations: List[str] = []
    local_tips: List[str] = []
    alternative_activities: List[ActivityItem] = []

class ItineraryVersionOut(BaseModel):
    id: str
    trip_id: str
    version: int
    itinerary_data: TripItinerary
    estimated_cost: float
    change_summary: Optional[str] = None
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)

class ModificationRequest(BaseModel):
    instruction: str
    target_day: Optional[int] = None
