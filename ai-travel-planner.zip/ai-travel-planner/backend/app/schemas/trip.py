from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
from datetime import date, datetime
from app.schemas.preference import PreferenceCreate, PreferenceOut
from app.schemas.itinerary import TripItinerary, ItineraryVersionOut

class TripBase(BaseModel):
    destination: str
    start_date: date
    end_date: date
    travelers: int = 1
    budget: float
    currency: str = "USD"
    travel_style: str = "balanced"

class TripCreate(TripBase):
    preferences: Optional[PreferenceCreate] = None

class TripUpdate(BaseModel):
    destination: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    travelers: Optional[int] = None
    budget: Optional[float] = None
    currency: Optional[str] = None
    travel_style: Optional[str] = None

class TripOut(TripBase):
    id: str
    user_id: Optional[int] = None
    duration_days: int
    created_at: datetime
    latest_itinerary: Optional[TripItinerary] = None
    latest_version: Optional[int] = None

    model_config = ConfigDict(from_attributes=True)

class TripDetailOut(TripOut):
    preferences: Optional[PreferenceOut] = None
    itineraries: List[ItineraryVersionOut] = []
