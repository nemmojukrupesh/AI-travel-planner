from pydantic import BaseModel
from typing import List, Optional

class PlaceItem(BaseModel):
    id: Optional[str] = None
    name: str
    category: str
    latitude: float
    longitude: float
    address: str = ""
    rating: float = 4.5
    price_level: int = 2
    is_indoor: bool = False
    opening_hours: str = "09:00 - 18:00"
    description: str = ""

class PlaceSearchResponse(BaseModel):
    destination: str
    total_results: int
    places: List[PlaceItem]
