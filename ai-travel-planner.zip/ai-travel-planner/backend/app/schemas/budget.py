from pydantic import BaseModel
from typing import List, Dict, Any
from app.schemas.itinerary import BudgetBreakdown, TripItinerary

class BudgetOptimizationResponse(BaseModel):
    trip_id: str
    original_cost: float
    optimized_cost: float
    user_budget: float
    currency: str
    savings: float
    is_within_budget: bool
    changes_made: List[str]
    optimized_itinerary: TripItinerary

class BudgetSummaryResponse(BaseModel):
    trip_id: str
    budget_breakdown: BudgetBreakdown
    category_percentages: Dict[str, float]
