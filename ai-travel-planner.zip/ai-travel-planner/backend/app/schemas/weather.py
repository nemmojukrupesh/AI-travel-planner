from pydantic import BaseModel
from typing import List, Optional

class DailyForecast(BaseModel):
    date: str
    temperature_max_c: float
    temperature_min_c: float
    condition: str
    precipitation_probability: int
    is_outdoor_friendly: bool
    summary: str

class WeatherResponse(BaseModel):
    destination: str
    latitude: float
    longitude: float
    current_temp_c: float
    condition: str
    daily_forecasts: List[DailyForecast]
