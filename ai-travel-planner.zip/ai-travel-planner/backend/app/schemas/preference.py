from pydantic import BaseModel, ConfigDict
from typing import List, Optional

class PreferenceBase(BaseModel):
    interests: List[str] = []
    food_preferences: List[str] = []
    accommodation_preference: str = "hotel"
    transportation_preference: str = "public_transit"
    special_requirements: Optional[str] = None

class PreferenceCreate(PreferenceBase):
    pass

class PreferenceOut(PreferenceBase):
    id: int
    trip_id: str

    model_config = ConfigDict(from_attributes=True)
