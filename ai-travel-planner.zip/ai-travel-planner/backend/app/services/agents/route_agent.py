from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.services.optimizer.route_optimizer import route_optimizer

class RouteOptimizationAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="RouteOptimizationAgent", role="Route & Transit Optimizer")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        dest = context["destination"]
        transport = context.get("transportation_preference", "metro")
        self.log(f"Optimizing geographical clusters and transit times for '{dest}' via {transport}")

        raw_acts = context.get("available_activities", [])
        days = int(context.get("duration_days", 3))
        clustered = route_optimizer.cluster_activities_by_proximity(raw_acts, days)
        context["clustered_activities"] = clustered
        return context
