from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.services.optimizer.budget_optimizer import budget_optimizer

class BudgetAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="BudgetAgent", role="Budget & Cost Allocator")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        budget = float(context.get("budget", 1000.0))
        curr = context.get("currency", "USD")
        self.log(f"Monitoring budget limits ({curr} {budget:,.2f}) and cost distributions")
        context["budget_checked"] = True
        return context
