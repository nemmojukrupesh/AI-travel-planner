from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.services.adapters.places_adapter import places_service

class ActivityAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="ActivityAgent", role="Attraction & Activity Specialist")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        dest = context["destination"]
        duration_days = int(context.get("duration_days", 3))
        interests = context.get("interests", [])
        self.log(f"Finding top activities for '{dest}' matching interests: {interests}")

        places = await places_service.search_places(destination=dest, limit=duration_days * 5)
        context["available_activities"] = places
        return context
