from typing import Dict, Any, List, Optional
from app.services.agents.base_agent import BaseAgent
from app.schemas.itinerary import TripItinerary
from app.services.llm.client import llm_client

class TravelAssistantAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="TravelAssistantAgent", role="Conversational Assistant & Delta Modifier")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        user_msg = context["user_message"]
        current_itinerary: TripItinerary = context["current_itinerary"]
        self.log(f"Processing conversational modification: '{user_msg}'")

        reply, updated_itinerary, changes = await llm_client.chat_modification(
            current_itinerary=current_itinerary,
            user_message=user_msg
        )

        context["reply"] = reply
        context["updated_itinerary"] = updated_itinerary
        context["changes_made"] = changes
        return context

travel_assistant_agent = TravelAssistantAgent()
