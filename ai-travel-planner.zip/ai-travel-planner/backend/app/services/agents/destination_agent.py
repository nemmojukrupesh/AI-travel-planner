from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.services.rag.retriever import rag_retriever

class DestinationAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="DestinationAgent", role="Destination & Context Analyzer")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        dest = context["destination"]
        interests = context.get("interests", [])
        self.log(f"Analyzing destination profile and cultural context for '{dest}'")

        # Grounding with RAG
        rag_data = rag_retriever.retrieve_context(
            query=f"{dest} culture safety highlights {' '.join(interests)}",
            destination=dest,
            top_k=3
        )

        context["destination_profile"] = {
            "destination": dest,
            "rag_context": rag_data["context_text"],
            "sources": rag_data["sources"],
            "analyzed": True
        }
        return context
