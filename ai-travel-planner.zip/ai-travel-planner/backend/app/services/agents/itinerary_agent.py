from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.schemas.itinerary import TripItinerary
from app.services.llm.client import llm_client

class ItineraryAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="ItineraryAgent", role="Master Itinerary Synthesizer")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        dest = context["destination"]
        self.log(f"Synthesizing structured itinerary payload for '{dest}'")

        itinerary = await llm_client.generate_itinerary(context)
        context["final_itinerary"] = itinerary
        return context
