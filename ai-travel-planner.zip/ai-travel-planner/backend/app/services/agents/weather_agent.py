from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent
from app.services.adapters.weather_adapter import weather_service

class WeatherAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="WeatherAgent", role="Meteorological & Climate Intelligence")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        dest = context["destination"]
        days = int(context.get("duration_days", 3))
        self.log(f"Retrieving weather forecast for '{dest}' ({days} days)")

        forecast_data = await weather_service.get_forecast(dest, days=days)
        context["weather_forecast"] = forecast_data
        return context
