from typing import Dict, Any, List
from app.services.agents.destination_agent import DestinationAgent
from app.services.agents.activity_agent import ActivityAgent
from app.services.agents.food_agent import FoodAgent
from app.services.agents.weather_agent import WeatherAgent
from app.services.agents.route_agent import RouteOptimizationAgent
from app.services.agents.budget_agent import BudgetAgent
from app.services.agents.itinerary_agent import ItineraryAgent
from app.schemas.itinerary import TripItinerary
from app.core.logging import logger

class MultiAgentOrchestrator:
    def __init__(self):
        self.destination_agent = DestinationAgent()
        self.activity_agent = ActivityAgent()
        self.food_agent = FoodAgent()
        self.weather_agent = WeatherAgent()
        self.route_agent = RouteOptimizationAgent()
        self.budget_agent = BudgetAgent()
        self.itinerary_agent = ItineraryAgent()

    async def plan_trip(self, trip_data: Dict[str, Any]) -> TripItinerary:
        logger.info(f"=== Starting Multi-Agent Itinerary Planning for {trip_data.get('destination')} ===")
        context = trip_data.copy()

        # Step 1: Destination Agent analyzes profile & RAG
        context = await self.destination_agent.process(context)

        # Step 2: Weather Agent checks climate & forecasts
        context = await self.weather_agent.process(context)

        # Step 3: Activity Agent finds suitable attractions
        context = await self.activity_agent.process(context)

        # Step 4: Route Optimization Agent clusters geographically
        context = await self.route_agent.process(context)

        # Step 5: Food Agent curates restaurants & dining
        context = await self.food_agent.process(context)

        # Step 6: Budget Agent checks financial boundaries
        context = await self.budget_agent.process(context)

        # Step 7: Itinerary Agent synthesizes final structured response
        context = await self.itinerary_agent.process(context)

        logger.info(f"=== Successfully completed Multi-Agent Itinerary Planning ===")
        return context["final_itinerary"]

orchestrator = MultiAgentOrchestrator()
