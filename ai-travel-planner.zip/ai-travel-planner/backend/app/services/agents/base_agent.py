from abc import ABC, abstractmethod
from typing import Dict, Any
from app.core.logging import logger

class BaseAgent(ABC):
    def __init__(self, name: str, role: str):
        self.name = name
        self.role = role

    @abstractmethod
    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent task and return enriched context."""
        pass

    def log(self, message: str):
        logger.info(f"[{self.name} - {self.role}] {message}")
