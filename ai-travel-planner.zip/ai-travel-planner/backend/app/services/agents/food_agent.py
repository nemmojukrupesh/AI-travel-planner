from typing import Dict, Any
from app.services.agents.base_agent import BaseAgent

class FoodAgent(BaseAgent):
    def __init__(self):
        super().__init__(name="FoodAgent", role="Culinary & Dining Specialist")

    async def process(self, context: Dict[str, Any]) -> Dict[str, Any]:
        food_prefs = context.get("food_preferences", [])
        dest = context["destination"]
        self.log(f"Curating dining recommendations in '{dest}' for preferences: {food_prefs}")
        context["food_curated"] = True
        return context
