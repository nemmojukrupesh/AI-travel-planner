from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional

class BaseWeatherAdapter(ABC):
    @abstractmethod
    async def get_forecast(self, destination: str, days: int = 7) -> Dict[str, Any]:
        pass

class BasePlacesAdapter(ABC):
    @abstractmethod
    async def search_places(self, destination: str, category: Optional[str] = None, limit: int = 15) -> List[Dict[str, Any]]:
        pass

class BaseCurrencyAdapter(ABC):
    @abstractmethod
    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        pass

    @abstractmethod
    def get_rate(self, from_currency: str, to_currency: str) -> float:
        pass

class BaseHotelAdapter(ABC):
    @abstractmethod
    async def search_hotels(self, destination: str, travel_style: str, budget: float, nights: int) -> List[Dict[str, Any]]:
        pass
