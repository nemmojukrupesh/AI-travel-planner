import httpx
from typing import List, Dict, Any, Optional
from app.services.adapters.base import BasePlacesAdapter
from app.core.logging import logger

FALLBACK_DESTINATION_PLACES = {
    "hyderabad": [
        {"name": "Charminar", "category": "historical", "latitude": 17.3616, "longitude": 78.4747, "rating": 4.6, "price_level": 1, "is_indoor": False, "description": "Iconic 16th-century mosque with 4 grand minarets and vibrant surrounding bazaar."},
        {"name": "Golconda Fort", "category": "historical", "latitude": 17.3833, "longitude": 78.4011, "rating": 4.7, "price_level": 2, "is_indoor": False, "description": "Medieval fortress known for acoustic architecture and panoramic views."},
        {"name": "Chowmahalla Palace", "category": "historical", "latitude": 17.3578, "longitude": 78.4717, "rating": 4.6, "price_level": 2, "is_indoor": True, "description": "Opulent palace of the Nizams with courtyards and vintage car collection."},
        {"name": "Salar Jung Museum", "category": "museum", "latitude": 17.3713, "longitude": 78.4804, "rating": 4.5, "price_level": 1, "is_indoor": True, "description": "One of the world's largest one-man art collections, featuring the Veiled Rebecca."},
        {"name": "Hussain Sagar Lake & Buddha Statue", "category": "nature", "latitude": 17.4239, "longitude": 78.4738, "rating": 4.4, "price_level": 1, "is_indoor": False, "description": "Heart-shaped lake featuring boat rides to the monolithic Buddha statue."},
        {"name": "Qutb Shahi Tombs", "category": "historical", "latitude": 17.3949, "longitude": 78.3957, "rating": 4.5, "price_level": 1, "is_indoor": False, "description": "Domed royal tombs set in landscaped gardens reflecting Persian and Hindu styles."},
        {"name": "Ramoji Film City", "category": "entertainment", "latitude": 17.2543, "longitude": 78.6808, "rating": 4.5, "price_level": 3, "is_indoor": False, "description": "World's largest integrated film studio complex with theme park attractions."},
        {"name": "Laad Bazaar", "category": "shopping", "latitude": 17.3619, "longitude": 78.4735, "rating": 4.4, "price_level": 1, "is_indoor": False, "description": "Historic market famed for traditional lacquer bangles, pearls, and bridal wear."},
        {"name": "Birla Mandir", "category": "culture", "latitude": 17.4062, "longitude": 78.4691, "rating": 4.7, "price_level": 0, "is_indoor": True, "description": "White Rajasthani marble temple perched on Naubat Pahad overlooking the city."},
        {"name": "Shilparamam Arts & Crafts Village", "category": "culture", "latitude": 17.4526, "longitude": 78.3772, "rating": 4.3, "price_level": 1, "is_indoor": False, "description": "Traditional village showcase with ethnic handicrafts, performances, and street food."}
    ],
    "paris": [
        {"name": "Eiffel Tower", "category": "historical", "latitude": 48.8584, "longitude": 2.2945, "rating": 4.8, "price_level": 3, "is_indoor": False, "description": "Wrought-iron lattice tower on the Champ de Mars, iconic symbol of France."},
        {"name": "Louvre Museum", "category": "museum", "latitude": 48.8606, "longitude": 2.3376, "rating": 4.8, "price_level": 3, "is_indoor": True, "description": "World's largest museum housing the Mona Lisa, Venus de Milo, and Winged Victory."},
        {"name": "Cathédrale Notre-Dame de Paris", "category": "historical", "latitude": 48.8530, "longitude": 2.3499, "rating": 4.7, "price_level": 0, "is_indoor": True, "description": "Gothic cathedral masterpiece situated on Île de la Cité."},
        {"name": "Montmartre & Sacré-Cœur", "category": "culture", "latitude": 48.8867, "longitude": 2.3431, "rating": 4.7, "price_level": 0, "is_indoor": False, "description": "Bohemian hilltop district with artists, cafes, and breathtaking city vistas."},
        {"name": "Musée d'Orsay", "category": "museum", "latitude": 48.8599, "longitude": 2.3265, "rating": 4.8, "price_level": 3, "is_indoor": True, "description": "Former Beaux-Arts railway station featuring Impressionist masterpieces by Monet, Van Gogh."},
        {"name": "Arc de Triomphe & Champs-Élysées", "category": "historical", "latitude": 48.8738, "longitude": 2.2950, "rating": 4.7, "price_level": 2, "is_indoor": False, "description": "Triumphal arch honouring French soldiers and famous tree-lined luxury avenue."},
        {"name": "Sainte-Chapelle", "category": "historical", "latitude": 48.8554, "longitude": 2.3450, "rating": 4.8, "price_level": 2, "is_indoor": True, "description": "13th-century royal chapel renowned for its radiant stained glass windows."},
        {"name": "Seine River Sightseeing Cruise", "category": "entertainment", "latitude": 48.8590, "longitude": 2.2930, "rating": 4.6, "price_level": 2, "is_indoor": False, "description": "Scenic boat cruise gliding past illuminated Parisian bridges and monuments."}
    ],
    "tokyo": [
        {"name": "Senso-ji Temple", "category": "historical", "latitude": 35.7147, "longitude": 139.7967, "rating": 4.7, "price_level": 0, "is_indoor": False, "description": "Tokyo's oldest Buddhist temple in Asakusa with the iconic Kaminarimon gate."},
        {"name": "Meiji Shrine & Yoyogi Park", "category": "culture", "latitude": 35.6764, "longitude": 139.6993, "rating": 4.7, "price_level": 0, "is_indoor": False, "description": "Tranquil Shinto shrine nested in an expansive sacred evergreen forest."},
        {"name": "Shibuya Crossing & Hachiko", "category": "sightseeing", "latitude": 35.6595, "longitude": 139.7004, "rating": 4.6, "price_level": 0, "is_indoor": False, "description": "The world's busiest pedestrian scramble crossing and famous loyal dog statue."},
        {"name": "teamLab Planets TOKYO", "category": "museum", "latitude": 35.6493, "longitude": 139.7898, "rating": 4.8, "price_level": 3, "is_indoor": True, "description": "Immersive digital art museum where visitors walk through water and light installations."},
        {"name": "Tokyo Skytree", "category": "sightseeing", "latitude": 35.7100, "longitude": 139.8107, "rating": 4.6, "price_level": 3, "is_indoor": True, "description": "Tallest tower in Japan with 360-degree observation decks looking out to Mount Fuji."},
        {"name": "Akihabara Electric Town", "category": "shopping", "latitude": 35.6983, "longitude": 139.7731, "rating": 4.5, "price_level": 2, "is_indoor": False, "description": "Hub for electronics, anime, gaming culture, and themed maid cafes."},
        {"name": "Tsukiji Outer Market", "category": "food", "latitude": 35.6655, "longitude": 139.7708, "rating": 4.6, "price_level": 2, "is_indoor": False, "description": "Lively street market packed with fresh sashimi, grilled wagyu, and tamagoyaki."}
    ],
    "new york": [
        {"name": "Central Park", "category": "nature", "latitude": 40.7851, "longitude": -73.9683, "rating": 4.8, "price_level": 0, "is_indoor": False, "description": "843-acre urban park with Bethesda Terrace, Bow Bridge, and scenic paths."},
        {"name": "The Metropolitan Museum of Art (The Met)", "category": "museum", "latitude": 40.7794, "longitude": -73.9632, "rating": 4.9, "price_level": 3, "is_indoor": True, "description": "Encyclopedic museum with over 2 million artworks spanning 5,000 years."},
        {"name": "Empire State Building / Summit One", "category": "sightseeing", "latitude": 40.7484, "longitude": -73.9857, "rating": 4.7, "price_level": 3, "is_indoor": True, "description": "Art Deco skyscraper offering panoramic vistas across Manhattan."},
        {"name": "Statue of Liberty & Ellis Island", "category": "historical", "latitude": 40.6892, "longitude": -74.0445, "rating": 4.7, "price_level": 2, "is_indoor": False, "description": "Universal symbol of freedom on Liberty Island in New York Harbor."},
        {"name": "Times Square & Broadway", "category": "entertainment", "latitude": 40.7580, "longitude": -73.9855, "rating": 4.6, "price_level": 3, "is_indoor": False, "description": "Bustling illuminated theater district with Broadway musicals and neon billboards."},
        {"name": "The High Line & Chelsea Market", "category": "culture", "latitude": 40.7480, "longitude": -74.0048, "rating": 4.7, "price_level": 1, "is_indoor": False, "description": "Elevated freight rail line turned urban greenway and premier artisan food hall."}
    ]
}

class PlacesAdapter(BasePlacesAdapter):
    def __init__(self):
        self.timeout = 5.0

    async def search_places(self, destination: str, category: Optional[str] = None, limit: int = 15) -> List[Dict[str, Any]]:
        dest_clean = destination.lower().strip()
        
        # Check predefined rich database first
        for city, places in FALLBACK_DESTINATION_PLACES.items():
            if city in dest_clean:
                filtered = places
                if category and category.lower() != "all":
                    filtered = [p for p in places if p["category"].lower() == category.lower()]
                    if not filtered:
                        filtered = places
                return filtered[:limit]

        # Try OpenStreetMap Nominatim for general places
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                query = f"tourist attractions in {destination}" if not category else f"{category} in {destination}"
                res = await client.get(
                    "https://nominatim.openstreetmap.org/search",
                    params={"q": query, "format": "json", "limit": limit, "addressdetails": 1},
                    headers={"User-Agent": "AITravelPlanner/1.0 (contact@example.com)"}
                )
                if res.status_code == 200:
                    data = res.json()
                    if data:
                        results = []
                        for item in data:
                            results.append({
                                "name": item.get("display_name", "").split(",")[0],
                                "category": category or "sightseeing",
                                "latitude": float(item.get("lat", 0.0)),
                                "longitude": float(item.get("lon", 0.0)),
                                "address": item.get("display_name", ""),
                                "rating": 4.5,
                                "price_level": 2,
                                "is_indoor": False,
                                "description": f"Popular destination landmark in {destination}."
                            })
                        return results
        except Exception as e:
            logger.warning(f"OSM Places search error: {e}")

        # Dynamic fallback for generic cities
        return [
            {"name": f"{destination.title()} Old Town & Historic Center", "category": "historical", "latitude": 20.0, "longitude": 75.0, "rating": 4.6, "price_level": 1, "is_indoor": False, "description": f"Historic heart of {destination} with authentic architecture."},
            {"name": f"{destination.title()} Central Museum of Art & History", "category": "museum", "latitude": 20.02, "longitude": 75.02, "rating": 4.7, "price_level": 2, "is_indoor": True, "description": f"Curated cultural and archaeological exhibits of {destination}."},
            {"name": f"{destination.title()} Botanical Gardens & Scenic Park", "category": "nature", "latitude": 20.01, "longitude": 75.04, "rating": 4.5, "price_level": 0, "is_indoor": False, "description": "Lush walking trails and native flora."},
            {"name": f"{destination.title()} Main Promenade & Market Square", "category": "shopping", "latitude": 20.03, "longitude": 75.01, "rating": 4.4, "price_level": 2, "is_indoor": False, "description": f"Vibrant artisan shopping and street cafes in {destination}."}
        ]

places_service = PlacesAdapter()
