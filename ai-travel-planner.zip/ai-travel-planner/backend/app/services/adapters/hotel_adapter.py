from typing import List, Dict, Any
from app.services.adapters.base import BaseHotelAdapter
from app.services.adapters.currency_adapter import currency_service

HOTEL_CATALOG = {
    "hyderabad": {
        "budget": {"name": "Treebo Trend Central Hyderabad", "stars": 3, "rate_inr": 1800, "rating": 4.2, "amenities": ["Free Wi-Fi", "Breakfast", "Air Conditioning"], "why": "Central location near metro with high cleanliness score."},
        "balanced": {"name": "Lemon Tree Premier Hitec City", "stars": 4, "rate_inr": 4500, "rating": 4.5, "amenities": ["Pool", "Fitness Center", "Restaurant", "Wi-Fi"], "why": "Upscale comfort close to major attractions and dining."},
        "luxury": {"name": "Taj Falaknuma Palace", "stars": 5, "rate_inr": 35000, "rating": 4.9, "amenities": ["Heritage Suites", "Fine Dining", "Spa", "Butler Service"], "why": "Historic Nizam palace offering an unforgettable royal experience."}
    },
    "paris": {
        "budget": {"name": "Generator Paris (Private Room)", "stars": 3, "rate_inr": 8000, "rating": 4.3, "amenities": ["Rooftop Bar", "Wi-Fi", "Metro Access"], "why": "Trendy design hotel steps from Canal Saint-Martin."},
        "balanced": {"name": "Hotel Le Relais Montmartre", "stars": 4, "rate_inr": 18000, "rating": 4.6, "amenities": ["Boutique Courtyard", "Breakfast", "Historic Charm"], "why": "Charming Parisian boutique hotel in the heart of Montmartre."},
        "luxury": {"name": "The Ritz Paris", "stars": 5, "rate_inr": 90000, "rating": 4.9, "amenities": ["Chanel Spa", "Michelin Dining", "Historic Salon"], "why": "Legendary luxury at Place Vendôme."}
    },
    "tokyo": {
        "budget": {"name": "APA Hotel Shinjuku-Kabukicho", "stars": 3, "rate_inr": 6000, "rating": 4.2, "amenities": ["Public Onsen Bath", "Compact Smart Rooms", "Wi-Fi"], "why": "Super convenient spot near Shinjuku Station."},
        "balanced": {"name": "Hotel Gracery Shinjuku", "stars": 4, "rate_inr": 14000, "rating": 4.5, "amenities": ["Godzilla Terrace", "City Views", "Lounge"], "why": "Modern central hotel within easy reach of all rail lines."},
        "luxury": {"name": "Aman Tokyo", "stars": 5, "rate_inr": 85000, "rating": 4.9, "amenities": ["Panoramic Spa", "Traditional Ryokan Aesthetics", "Wine Cellar"], "why": "Serene sanctuary soaring above the Otemachi business district."}
    }
}

class HotelAdapter(BaseHotelAdapter):
    async def search_hotels(self, destination: str, travel_style: str, budget: float, nights: int, currency: str = "USD") -> List[Dict[str, Any]]:
        dest_clean = destination.lower().strip()
        style_clean = travel_style.lower().strip()
        
        if "budget" in style_clean or "backpacker" in style_clean:
            tier = "budget"
        elif "luxury" in style_clean:
            tier = "luxury"
        else:
            tier = "balanced"

        # Check catalog
        for city, tiers in HOTEL_CATALOG.items():
            if city in dest_clean:
                hotel_data = tiers.get(tier, tiers["balanced"])
                rate_in_target = currency_service.convert(hotel_data["rate_inr"], "INR", currency)
                return [{
                    "name": hotel_data["name"],
                    "category": f"{hotel_data['stars']}-Star {tier.title()} Hotel",
                    "estimated_cost_per_night": round(rate_in_target, 2),
                    "total_cost": round(rate_in_target * max(1, nights), 2),
                    "rating": hotel_data["rating"],
                    "amenities": hotel_data["amenities"],
                    "why_recommended": hotel_data["why"],
                    "currency": currency
                }]

        # Dynamic fallback based on style and currency
        base_rate_usd = 45.0 if tier == "budget" else (110.0 if tier == "balanced" else 320.0)
        rate_in_target = currency_service.convert(base_rate_usd, "USD", currency)
        
        return [{
            "name": f"Grand {destination.title()} {tier.title()} Suites",
            "category": f"{4 if tier != 'budget' else 3}-Star {tier.title()} Accommodation",
            "estimated_cost_per_night": round(rate_in_target, 2),
            "total_cost": round(rate_in_target * max(1, nights), 2),
            "rating": 4.4,
            "amenities": ["Complimentary High-speed Wi-Fi", "Daily Breakfast", "Concierge", "Central Location"],
            "why_recommended": f"Prime location in central {destination.title()} with easy transit connections and excellent guest ratings.",
            "currency": currency
        }]

hotel_service = HotelAdapter()
