from typing import Dict
from app.services.adapters.base import BaseCurrencyAdapter

# Baseline exchange rates pegged to 1 USD
BASE_RATES_USD: Dict[str, float] = {
    "USD": 1.0,
    "INR": 83.5,
    "EUR": 0.92,
    "GBP": 0.78,
    "JPY": 155.0,
    "AUD": 1.50,
    "CAD": 1.36,
    "SGD": 1.35,
    "AED": 3.67,
    "CHF": 0.90,
    "THB": 36.5,
    "CNY": 7.25,
    "BRL": 5.15,
    "MXN": 16.80
}

class CurrencyAdapter(BaseCurrencyAdapter):
    def __init__(self):
        self.rates = BASE_RATES_USD

    def get_rate(self, from_currency: str, to_currency: str) -> float:
        from_cur = from_currency.upper().strip()
        to_cur = to_currency.upper().strip()
        
        if from_cur == to_cur:
            return 1.0

        rate_from = self.rates.get(from_cur, 1.0)
        rate_to = self.rates.get(to_cur, 1.0)

        # Convert from -> USD -> to
        return rate_to / rate_from

    def convert(self, amount: float, from_currency: str, to_currency: str) -> float:
        rate = self.get_rate(from_currency, to_currency)
        return round(amount * rate, 2)

currency_service = CurrencyAdapter()
