from app.services.adapters.weather_adapter import weather_service, OpenMeteoWeatherAdapter
from app.services.adapters.places_adapter import places_service, PlacesAdapter
from app.services.adapters.currency_adapter import currency_service, CurrencyAdapter
from app.services.adapters.hotel_adapter import hotel_service, HotelAdapter

__all__ = [
    "weather_service", "OpenMeteoWeatherAdapter",
    "places_service", "PlacesAdapter",
    "currency_service", "CurrencyAdapter",
    "hotel_service", "HotelAdapter"
]
