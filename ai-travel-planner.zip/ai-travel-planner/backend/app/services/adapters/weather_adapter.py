import httpx
from typing import Dict, Any, List
from datetime import datetime, timedelta
from app.services.adapters.base import BaseWeatherAdapter
from app.core.logging import logger

CITY_COORDINATES = {
    "hyderabad": (17.3850, 78.4867),
    "tokyo": (35.6762, 139.6503),
    "paris": (48.8566, 2.3522),
    "new york": (40.7128, -74.0060),
    "rome": (41.9028, 12.4964),
    "london": (51.5074, -0.1278),
    "bali": (-8.4095, 115.1889),
    "dubai": (25.2048, 55.2708),
    "barcelona": (41.3851, 2.1734),
    "singapore": (1.3521, 103.8198),
    "jaipur": (26.9124, 75.7873),
    "bangkok": (13.7563, 100.5018),
    "sydney": (-33.8688, 151.2093),
    "san francisco": (37.7749, -122.4194),
}

class OpenMeteoWeatherAdapter(BaseWeatherAdapter):
    def __init__(self):
        self.timeout = 5.0

    async def _geocode(self, destination: str) -> tuple[float, float]:
        city_lower = destination.lower().strip()
        for city, coords in CITY_COORDINATES.items():
            if city in city_lower:
                return coords
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    "https://geocoding-api.open-meteo.com/v1/search",
                    params={"name": destination, "count": 1, "language": "en", "format": "json"}
                )
                if res.status_code == 200:
                    data = res.json()
                    if "results" in data and len(data["results"]) > 0:
                        return data["results"][0]["latitude"], data["results"][0]["longitude"]
        except Exception as e:
            logger.warning(f"Geocoding failed for {destination}: {e}")
            
        return 17.3850, 78.4867  # Default fallback coordinates

    async def get_forecast(self, destination: str, days: int = 7) -> Dict[str, Any]:
        lat, lon = await self._geocode(destination)
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                res = await client.get(
                    "https://api.open-meteo.com/v1/forecast",
                    params={
                        "latitude": lat,
                        "longitude": lon,
                        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode",
                        "timezone": "auto",
                        "forecast_days": min(days, 14)
                    }
                )
                if res.status_code == 200:
                    data = res.json()
                    daily = data.get("daily", {})
                    forecasts = []
                    times = daily.get("time", [])
                    t_max = daily.get("temperature_2m_max", [])
                    t_min = daily.get("temperature_2m_min", [])
                    precip = daily.get("precipitation_probability_max", [])
                    codes = daily.get("weathercode", [])

                    for i in range(len(times)):
                        code = codes[i] if i < len(codes) else 0
                        condition, is_outdoor = self._interpret_weathercode(code)
                        rain_pct = int(precip[i]) if i < len(precip) and precip[i] is not None else 10
                        if rain_pct > 60:
                            is_outdoor = False

                        forecasts.append({
                            "date": times[i],
                            "temperature_max_c": round(t_max[i], 1) if i < len(t_max) else 25.0,
                            "temperature_min_c": round(t_min[i], 1) if i < len(t_min) else 18.0,
                            "condition": condition,
                            "precipitation_probability": rain_pct,
                            "is_outdoor_friendly": is_outdoor,
                            "summary": f"{condition}, highs of {t_max[i]}°C. {'Ideal for outdoor tours.' if is_outdoor else 'Pack an umbrella or plan indoor visits.'}"
                        })

                    return {
                        "destination": destination,
                        "latitude": lat,
                        "longitude": lon,
                        "current_temp_c": forecasts[0]["temperature_max_c"] if forecasts else 25.0,
                        "condition": forecasts[0]["condition"] if forecasts else "Clear Sky",
                        "daily_forecasts": forecasts
                    }
        except Exception as e:
            logger.warning(f"Weather API request failed: {e}. Using fallback forecast.")

        return self._generate_fallback_forecast(destination, lat, lon, days)

    def _interpret_weathercode(self, code: int) -> tuple[str, bool]:
        if code in [0, 1]:
            return "Clear & Sunny", True
        elif code in [2, 3]:
            return "Partly Cloudy", True
        elif code in [45, 48]:
            return "Foggy", True
        elif code in [51, 53, 55, 61, 63, 65]:
            return "Rainy / Showers", False
        elif code in [71, 73, 75, 77, 85, 86]:
            return "Snow / Flurries", False
        elif code in [95, 96, 99]:
            return "Thunderstorm", False
        return "Pleasant / Mild", True

    def _generate_fallback_forecast(self, destination: str, lat: float, lon: float, days: int) -> Dict[str, Any]:
        today = datetime.now()
        forecasts = []
        conditions = ["Sunny & Clear", "Partly Cloudy", "Pleasant Breeze", "Warm & Sunny", "Passing Cloud", "Sunny"]
        for i in range(days):
            d = today + timedelta(days=i)
            cond = conditions[i % len(conditions)]
            forecasts.append({
                "date": d.strftime("%Y-%m-%d"),
                "temperature_max_c": 28.0 + (i % 3),
                "temperature_min_c": 20.0 + (i % 2),
                "condition": cond,
                "precipitation_probability": 10 + (i * 5) % 25,
                "is_outdoor_friendly": True,
                "summary": f"{cond}, great conditions for sightseeing and dining."
            })
        return {
            "destination": destination,
            "latitude": lat,
            "longitude": lon,
            "current_temp_c": 27.5,
            "condition": "Sunny & Clear",
            "daily_forecasts": forecasts
        }

weather_service = OpenMeteoWeatherAdapter()
