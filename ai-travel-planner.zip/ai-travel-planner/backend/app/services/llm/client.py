import json
import httpx
from typing import Dict, Any, List, Optional
from app.core.config import settings
from app.core.logging import logger
from app.schemas.itinerary import TripItinerary
from app.services.llm.fallback_engine import fallback_engine

class LLMClient:
    def __init__(self):
        self.provider = settings.LLM_PROVIDER.lower()

    async def generate_itinerary(self, payload: Dict[str, Any]) -> TripItinerary:
        """Generate structured travel itinerary using configured LLM provider or fallback."""
        if self.provider == "openai" and settings.OPENAI_API_KEY:
            try:
                return await self._call_openai(payload)
            except Exception as e:
                logger.error(f"OpenAI generation failed: {e}. Falling back to deterministic engine.")
        elif self.provider == "gemini" and settings.GEMINI_API_KEY:
            try:
                return await self._call_gemini(payload)
            except Exception as e:
                logger.error(f"Gemini generation failed: {e}. Falling back to deterministic engine.")

        # Default / Fallback engine
        return await fallback_engine.generate_itinerary(
            destination=payload["destination"],
            start_date=str(payload["start_date"]),
            end_date=str(payload["end_date"]),
            duration_days=int(payload["duration_days"]),
            travelers=int(payload.get("travelers", 1)),
            budget=float(payload.get("budget", 1000.0)),
            currency=payload.get("currency", "USD"),
            travel_style=payload.get("travel_style", "balanced"),
            interests=payload.get("interests", []),
            food_preferences=payload.get("food_preferences", []),
            accommodation_preference=payload.get("accommodation_preference", "hotel"),
            transportation_preference=payload.get("transportation_preference", "public_transit")
        )

    async def chat_modification(
        self,
        current_itinerary: TripItinerary,
        user_message: str,
        chat_history: Optional[List[Dict[str, str]]] = None
    ) -> tuple[str, TripItinerary, List[str]]:
        """Handle conversational itinerary edit."""
        return await fallback_engine.handle_chat_modification(current_itinerary, user_message)

    async def _call_openai(self, payload: Dict[str, Any]) -> TripItinerary:
        # Structured JSON with OpenAI Chat Completions
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        system_prompt = (
            "You are a master AI Travel Planner. Generate a strictly valid JSON response matching the TripItinerary schema "
            "with trip_summary, hotel, days (morning_activities, afternoon_activities, evening_activities, meals, transportation), "
            "budget_breakdown, packing_suggestions, safety_recommendations, local_tips, and alternative_activities."
        )
        data = {
            "model": settings.OPENAI_MODEL,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Create itinerary for: {json.dumps(payload, default=str)}"}
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.3
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            res = await client.post(url, headers=headers, json=data)
            res.raise_for_status()
            res_json = res.json()
            raw_content = res_json["choices"][0]["message"]["content"]
            parsed = json.loads(raw_content)
            return TripItinerary(**parsed)

    async def _call_gemini(self, payload: Dict[str, Any]) -> TripItinerary:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{settings.GEMINI_MODEL}:generateContent?key={settings.GEMINI_API_KEY}"
        system_prompt = "You are a master AI Travel Planner. Return strictly a JSON object conforming to the TripItinerary schema."
        data = {
            "contents": [{
                "parts": [{"text": f"{system_prompt}\nUser Request: {json.dumps(payload, default=str)}"}]
            }],
            "generationConfig": {
                "response_mime_type": "application/json"
            }
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            res = await client.post(url, json=data)
            res.raise_for_status()
            res_json = res.json()
            text = res_json["candidates"][0]["content"]["parts"][0]["text"]
            parsed = json.loads(text)
            return TripItinerary(**parsed)

llm_client = LLMClient()
