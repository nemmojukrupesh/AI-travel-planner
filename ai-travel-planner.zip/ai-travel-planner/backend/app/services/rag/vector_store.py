import math
import re
from typing import List, Dict, Any, Optional
from collections import Counter
from app.services.rag.knowledge_base import TRAVEL_KNOWLEDGE_DOCUMENTS

class VectorStore:
    def __init__(self):
        self.documents: List[Dict[str, Any]] = []
        self.vocabulary: Dict[str, int] = {}
        self.idf: Dict[str, float] = {}
        self.doc_vectors: List[Dict[str, float]] = []
        self.initialize_documents(TRAVEL_KNOWLEDGE_DOCUMENTS)

    def _tokenize(self, text: str) -> List[str]:
        cleaned = re.sub(r"[^a-zA-Z0-9\s]", " ", text.lower())
        tokens = [t.strip() for t in cleaned.split() if len(t.strip()) > 2]
        return tokens

    def initialize_documents(self, raw_docs: List[Dict[str, Any]]):
        self.documents = raw_docs
        doc_count = len(self.documents)
        df_counts: Dict[str, int] = Counter()

        # Compute document frequency
        all_token_lists = []
        for doc in self.documents:
            full_text = f"{doc.get('destination', '')} {doc.get('title', '')} {doc.get('category', '')} {doc.get('content', '')} {' '.join(doc.get('tags', []))}"
            tokens = set(self._tokenize(full_text))
            all_token_lists.append(self._tokenize(full_text))
            for t in tokens:
                df_counts[t] += 1

        # Compute IDF
        self.idf = {term: math.log((doc_count + 1) / (df + 1)) + 1.0 for term, df in df_counts.items()}

        # Compute document TF-IDF vectors
        self.doc_vectors = []
        for token_list in all_token_lists:
            tf = Counter(token_list)
            length = len(token_list) if token_list else 1
            vec: Dict[str, float] = {}
            for term, count in tf.items():
                vec[term] = (count / length) * self.idf.get(term, 1.0)
            
            # Normalize vector
            norm = math.sqrt(sum(v * v for v in vec.values()))
            if norm > 0:
                vec = {k: v / norm for k, v in vec.items()}
            self.doc_vectors.append(vec)

    def similarity_search(self, query: str, destination: Optional[str] = None, top_k: int = 4) -> List[Dict[str, Any]]:
        query_tokens = self._tokenize(query)
        dest_filter = destination.lower().strip() if destination else None

        # Filter candidate pool if destination specified
        candidate_indices = []
        if dest_filter:
            for idx, doc in enumerate(self.documents):
                doc_dest = doc.get("destination", "").lower()
                if dest_filter in doc_dest or doc_dest in dest_filter:
                    candidate_indices.append(idx)
        
        if not candidate_indices:
            candidate_indices = list(range(len(self.documents)))

        if not query_tokens:
            return [self.documents[i] for i in candidate_indices[:top_k]]

        # Query vector
        tf = Counter(query_tokens)
        length = len(query_tokens)
        q_vec = {}
        for term, count in tf.items():
            if term in self.idf:
                q_vec[term] = (count / length) * self.idf[term]

        q_norm = math.sqrt(sum(v * v for v in q_vec.values()))
        if q_norm > 0:
            q_vec = {k: v / q_norm for k, v in q_vec.items()}

        # Cosine similarity for candidates
        scored_docs = []
        for idx in candidate_indices:
            doc = self.documents[idx]
            d_vec = self.doc_vectors[idx]

            # Dot product
            score = sum(q_vec.get(term, 0.0) * d_vec.get(term, 0.0) for term in d_vec)

            # Bonus for exact title keyword matching & tags
            for token in query_tokens:
                if token in doc.get("title", "").lower():
                    score += 0.4
                if token in doc.get("tags", []):
                    score += 0.25
                if token in doc.get("content", "").lower():
                    score += 0.1

            scored_docs.append((score, doc))

        scored_docs.sort(key=lambda x: x[0], reverse=True)
        return [doc for score, doc in scored_docs[:top_k]]

vector_store = VectorStore()
