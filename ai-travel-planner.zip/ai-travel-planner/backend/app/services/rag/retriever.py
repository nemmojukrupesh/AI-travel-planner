from typing import List, Dict, Any, Optional
from app.services.rag.vector_store import vector_store

class RAGRetriever:
    def __init__(self):
        self.store = vector_store

    def retrieve_context(self, query: str, destination: Optional[str] = None, top_k: int = 3) -> Dict[str, Any]:
        docs = self.store.similarity_search(query=query, destination=destination, top_k=top_k)
        
        formatted_context_chunks = []
        sources = []
        
        for doc in docs:
            formatted_context_chunks.append(
                f"### {doc.get('title')} ({doc.get('destination')})\n{doc.get('content')}"
            )
            sources.append({
                "id": doc.get("id"),
                "title": doc.get("title"),
                "destination": doc.get("destination"),
                "category": doc.get("category")
            })

        combined_context = "\n\n".join(formatted_context_chunks)

        return {
            "query": query,
            "destination": destination,
            "context_text": combined_context,
            "sources": sources,
            "raw_documents": docs
        }

rag_retriever = RAGRetriever()
