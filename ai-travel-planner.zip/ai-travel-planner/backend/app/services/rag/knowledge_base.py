from typing import List, Dict, Any

TRAVEL_KNOWLEDGE_DOCUMENTS: List[Dict[str, Any]] = [
    {
        "id": "hyd_01",
        "destination": "Hyderabad",
        "category": "attraction",
        "title": "Charminar & Laad Bazaar Guide",
        "content": "Charminar is a 16th-century architectural jewel built by Muhammad Quli Qutb Shah in 1591. Located in the heart of Old Hyderabad, it features four ornate 48.7m minarets. Entry ticket is ₹25 for Indians, ₹300 for foreigners. Timings: 09:00 - 17:30 daily. Surrounding Charminar is Laad Bazaar, renowned for handmade lacquer bangles, Basra pearls, zardozi embroidery, and traditional bridal jewelry. Best visited early morning or late afternoon to avoid heavy traffic.",
        "tags": ["history", "architecture", "shopping", "budget", "culture"]
    },
    {
        "id": "hyd_02",
        "destination": "Hyderabad",
        "category": "attraction",
        "title": "Golconda Fort & Qutb Shahi Tombs",
        "content": "Golconda Fort was the historic diamond capital of the medieval world where Koh-i-Noor was mined and traded. Features astounding acoustic engineering (a clap at Fateh Darwaza can be heard at the hilltop Bala Hissar 1km away). Entry: ₹25 Indians, ₹300 Foreigners. Timings: 09:00 - 17:30. Sound & Light show runs in English & Telugu in the evening (₹140). The nearby Qutb Shahi Tombs (1.5 km away) houses the mausoleums of 7 Qutb Shahi rulers in landscaped gardens.",
        "tags": ["history", "architecture", "monument", "acoustics"]
    },
    {
        "id": "hyd_03",
        "destination": "Hyderabad",
        "category": "food",
        "title": "Hyderabad Culinary Delicacies & Legendary Restaurants",
        "content": "Hyderabad's culinary culture is an exquisite blend of Mughlai, Turkish, and Telugu flavors. Must-try dishes: Hyderabadi Dum Biryani (Paradise, Bawarchi, Cafe Bahar, Shah Ghouse), Haleem (during Ramzan or Pista House), Double ka Meetha, Irani Chai with Osmania Biscuits (Nimrah Cafe near Charminar), and spicy Andhra meals (Kakatiya Mess). Average cost per person: ₹250-₹600 for dining.",
        "tags": ["food", "biryani", "irani chai", "culinary", "restaurants"]
    },
    {
        "id": "hyd_04",
        "destination": "Hyderabad",
        "category": "safety_tips",
        "title": "Hyderabad Local Transport & Travel Tips",
        "content": "Hyderabad has a modern Metro Rail network spanning 3 major corridors (Red, Blue, Green lines), making travel across Hitec City, Begumpet, and MGBS very quick and cheap (₹10-₹60). Auto-rickshaws are plentiful; always insist on meter or use Uber/Ola auto. Winters (October-February) are pleasant (15-28°C), while summers (March-May) can exceed 40°C. Tap water is not potable; drink bottled or RO filtered water.",
        "tags": ["transport", "safety", "weather", "metro", "tips"]
    },
    {
        "id": "hyd_05",
        "destination": "Hyderabad",
        "category": "attraction",
        "title": "Salar Jung Museum & Chowmahalla Palace",
        "content": "Salar Jung Museum is situated on the southern bank of Musi river, featuring 38 galleries of rare jade, porcelain, ivory, weapons, and the famous 19th-century musical clock. Closed on Fridays. Chowmahalla Palace near Charminar reflects neoclassical style with grand Durbar Hall (Khilwat Mubarak) holding 19 crystal chandeliers and royal vintage Rolls Royce collection.",
        "tags": ["museum", "history", "palace", "indoor", "art"]
    },
    {
        "id": "paris_01",
        "destination": "Paris",
        "category": "attraction",
        "title": "Louvre Museum and Eiffel Tower Visiting Protocol",
        "content": "Louvre Museum is the world's largest museum, housing the Mona Lisa, Venus de Milo, and Winged Victory of Samothrace. Closed on Tuesdays. Timed entry booking online is mandatory (€22). Eiffel Tower ticket to summit costs €35.30 with elevator; booking 2 months in advance is recommended. Paris Navigo Easy Pass or contactless t+ tickets provide effortless metro travel (€2.15/ride).",
        "tags": ["art", "museum", "landmarks", "tickets", "metro"]
    },
    {
        "id": "paris_02",
        "destination": "Paris",
        "category": "food",
        "title": "Authentic Parisian Bistros, Bakeries, and Etiquette",
        "content": "In Paris, greet shopkeepers with 'Bonjour Madame/Monsieur' upon entering. Try fresh croissants and pain au chocolat at artisanal boulangeries, steak frites or duck confit at classic bistros (Le Bouillon Chartier for budget luxury), and macarons from Pierre Hermé. Water ('une carafe d'eau') and bread are free by law in French dining establishments.",
        "tags": ["food", "etiquette", "bistro", "pastries"]
    },
    {
        "id": "tokyo_01",
        "destination": "Tokyo",
        "category": "attraction",
        "title": "Tokyo Neighborhoods, Temples, and Modern Wonders",
        "content": "Tokyo blends ultra-modern and ancient tradition seamlessly. Asakusa houses the Senso-ji Temple; Shibuya is famous for its scramble crossing; Shinjuku for skyline views at Tokyo Metropolitan Govt Building (free observation deck); Akihabara for gaming/anime culture; and Toyosu for sushi auctions. Use Suica or Pasmo IC cards or 72-hour Tokyo Subway Tourist Pass (¥1,500).",
        "tags": ["temple", "modern", "rail", "neighborhoods"]
    },
    {
        "id": "tokyo_02",
        "destination": "Tokyo",
        "category": "food_etiquette",
        "title": "Japanese Dining Etiquette & Must-Try Food",
        "content": "Tipping is strictly not customary in Japan and can cause confusion. Slurping noodles (ramen, udon, soba) is a compliment indicating appreciation. Try authentic Tonkotsu Ramen (Ichiran, Ippudo), conveyor-belt sushi (Sushiro), Yakitori in Omoide Yokocho, and matcha sweets in Ginza.",
        "tags": ["food", "ramen", "sushi", "culture", "etiquette"]
    },
    {
        "id": "nyc_01",
        "destination": "New York",
        "category": "attraction",
        "title": "NYC Transit, Broadway, and Major Landmarks",
        "content": "New York City's MTA subway runs 24/7. Use OMNY contactless payment ($2.90 per ride with a $34 weekly fare cap). Central Park, High Line, and Staten Island Ferry (passing Statue of Liberty) are completely free. TKTS booth at Times Square offers 20-50% discounts on same-day Broadway musicals.",
        "tags": ["transit", "broadway", "budget", "landmarks"]
    },
    {
        "id": "rome_01",
        "destination": "Rome",
        "category": "attraction",
        "title": "Colosseum, Vatican Museums, and Roman Walking Routes",
        "content": "Book Colosseum and Vatican Museum tickets online weeks in advance to avoid 3-hour queues. Modest dress (covered shoulders and knees) is strictly enforced in St. Peter's Basilica. Rome is exceptionally walkable; drink from free historical 'nasoni' water fountains found on every street corner.",
        "tags": ["history", "vatican", "colosseum", "walking", "safety"]
    },
    {
        "id": "bali_01",
        "destination": "Bali",
        "category": "attraction",
        "title": "Bali Culture, Ubud Rice Terraces, and Coastal Temples",
        "content": "Bali offers rich spiritual heritage in Ubud (Monkey Forest, Tegalalang Rice Terraces, Saraswati Temple) and dramatic coastal temples like Uluwatu (Kecak fire dance at sunset) and Tanah Lot. Hire a private driver (approx. $40-$50 USD/day) or rent a scooter with international driving permit. Respect local temple ceremonies by wearing a sarong and sash.",
        "tags": ["nature", "temple", "beaches", "budget", "culture"]
    }
]
