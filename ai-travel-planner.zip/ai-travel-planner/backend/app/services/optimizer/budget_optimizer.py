from typing import Dict, Any, List, Tuple
import copy
from app.schemas.itinerary import TripItinerary, BudgetBreakdown

class BudgetOptimizer:
    def calculate_total_breakdown(self, itinerary: TripItinerary, travelers: int = 1) -> BudgetBreakdown:
        travelers = max(1, travelers)
        
        # Hotel total
        accommodation_cost = itinerary.hotel.total_cost
        
        # Activities & Meals & Transit
        activities_cost = 0.0
        food_cost = 0.0
        transit_cost = 0.0

        for day in itinerary.days:
            # Activities
            for act in day.morning_activities + day.afternoon_activities + day.evening_activities:
                activities_cost += act.estimated_cost * travelers
                if act.travel_from_prev:
                    transit_cost += act.travel_from_prev.estimated_cost
            
            # Meals
            for meal in day.meals:
                food_cost += meal.estimated_cost * travelers
                
            # Direct day transport
            for tr in day.transportation:
                transit_cost += tr.estimated_cost

        miscellaneous = round((accommodation_cost + food_cost + activities_cost + transit_cost) * 0.08, 2)
        total_estimated = round(accommodation_cost + food_cost + activities_cost + transit_cost + miscellaneous, 2)
        user_budget = itinerary.trip_summary.budget

        is_over = total_estimated > user_budget
        overrun = round(total_estimated - user_budget, 2) if is_over else 0.0

        suggestions = []
        if is_over:
            suggestions.append(f"Trip is exceeding budget by {itinerary.trip_summary.currency} {overrun:,.2f}.")
            if accommodation_cost > user_budget * 0.4:
                suggestions.append("Switch to a mid-range or boutique hotel/apartment to reduce accommodation expenses by 25-40%.")
            if activities_cost > user_budget * 0.25:
                suggestions.append("Replace premium ticketed attractions with landmark architecture visits and free historic walking tours.")
            if food_cost > user_budget * 0.3:
                suggestions.append("Enjoy authentic local food markets and bistro lunch specials instead of fine dining dinners.")
            if transit_cost > user_budget * 0.15:
                suggestions.append("Utilize multi-day transit passes or metro lines instead of point-to-point taxis.")
        else:
            remaining = round(user_budget - total_estimated, 2)
            suggestions.append(f"Great news! Your estimated expenses are within budget with a {itinerary.trip_summary.currency} {remaining:,.2f} buffer.")

        return BudgetBreakdown(
            accommodation=round(accommodation_cost, 2),
            food=round(food_cost, 2),
            transport=round(transit_cost, 2),
            activities=round(activities_cost, 2),
            miscellaneous=miscellaneous,
            total_estimated=total_estimated,
            user_budget=user_budget,
            currency=itinerary.trip_summary.currency,
            is_over_budget=is_over,
            overrun_amount=overrun,
            savings_suggestions=suggestions
        )

    def optimize_to_budget(self, itinerary: TripItinerary) -> Tuple[TripItinerary, List[str], float, float]:
        """
        Reduces costs automatically to meet user budget while preserving itinerary quality.
        Returns (optimized_itinerary, changes_made, original_cost, new_cost).
        """
        optimized = copy.deepcopy(itinerary)
        original_breakdown = self.calculate_total_breakdown(itinerary, itinerary.trip_summary.travelers)
        original_cost = original_breakdown.total_estimated
        user_budget = itinerary.trip_summary.budget
        changes_made: List[str] = []

        if original_cost <= user_budget:
            changes_made.append("Itinerary is already within the specified budget.")
            return optimized, changes_made, original_cost, original_cost

        # 1. Optimize Hotel if expensive
        if optimized.hotel.total_cost > user_budget * 0.35:
            old_cost = optimized.hotel.total_cost
            optimized.hotel.name = f"{optimized.trip_summary.destination.title()} Central Boutique Suites"
            optimized.hotel.category = "3-Star Value Boutique Hotel"
            optimized.hotel.estimated_cost_per_night = round(optimized.hotel.estimated_cost_per_night * 0.65, 2)
            optimized.hotel.total_cost = round(old_cost * 0.65, 2)
            savings = round(old_cost - optimized.hotel.total_cost, 2)
            changes_made.append(f"Swapped accommodation to a high-rated boutique hotel, saving {optimized.trip_summary.currency} {savings:,.2f}.")

        # 2. Optimize Activities
        for day in optimized.days:
            for act in day.morning_activities + day.afternoon_activities + day.evening_activities:
                if act.estimated_cost > 300.0:
                    old_cost = act.estimated_cost
                    act.estimated_cost = round(act.estimated_cost * 0.3, 2)
                    act.reason += " (Optimized to discounted advance/free self-guided tour)."
                    changes_made.append(f"Selected standard/self-guided entry for {act.name}.")

        # 3. Optimize Dining
        for day in optimized.days:
            for meal in day.meals:
                if meal.estimated_cost > 400.0:
                    meal.estimated_cost = round(meal.estimated_cost * 0.65, 2)
                    meal.reason += " (Selected authentic local specialty diner)."
                    changes_made.append(f"Recommended authentic local eatery for {meal.meal_type} on Day {day.day}.")

        # Recompute
        new_breakdown = self.calculate_total_breakdown(optimized, optimized.trip_summary.travelers)
        optimized.budget_breakdown = new_breakdown
        new_cost = new_breakdown.total_estimated

        return optimized, changes_made, original_cost, new_cost

budget_optimizer = BudgetOptimizer()
