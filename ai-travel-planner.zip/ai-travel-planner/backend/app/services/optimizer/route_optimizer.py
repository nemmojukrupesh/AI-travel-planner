import math
from typing import List, Dict, Any, Tuple
from app.schemas.itinerary import ActivityItem, TravelTransit, GeoLocation

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate distance in kilometers between two GPS coordinates using Haversine formula."""
    if lat1 == 0.0 or lon1 == 0.0 or lat2 == 0.0 or lon2 == 0.0:
        return 2.5  # Standard average distance fallback

    R = 6371.0  # Earth radius in kilometers
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2.0) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2.0) ** 2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))
    return round(R * c, 2)

def estimate_travel_metrics(distance_km: float, mode: str = "metro") -> Tuple[int, float]:
    """Return estimated travel duration in minutes and cost based on distance and mode."""
    if distance_km <= 1.2:
        # Walkable
        duration = max(5, int(distance_km * 12))  # ~5 km/h
        cost = 0.0
        return duration, cost
    elif mode == "metro" or mode == "public_transit":
        duration = max(10, int(distance_km * 2.5) + 5)  # transit wait + travel
        cost = min(50.0, max(15.0, distance_km * 4.0))  # in local currency approx
        return duration, cost
    else:  # cab / taxi / drive
        duration = max(8, int(distance_km * 3.0))
        cost = max(80.0, distance_km * 18.0)
        return duration, cost

class RouteOptimizer:
    def optimize_day_schedule(self, activities: List[ActivityItem], transport_mode: str = "metro") -> List[ActivityItem]:
        """
        Sort activities using Nearest-Neighbor TSP heuristic starting from the first activity
        and attach realistic transit metrics between consecutive stops.
        """
        if len(activities) <= 1:
            return activities

        unvisited = activities.copy()
        ordered: List[ActivityItem] = []

        # Start with the highest rated or first activity
        current = unvisited.pop(0)
        ordered.append(current)

        while unvisited:
            best_idx = 0
            best_dist = float("inf")
            curr_loc = current.location

            for idx, candidate in enumerate(unvisited):
                dist = haversine_distance(
                    curr_loc.latitude, curr_loc.longitude,
                    candidate.location.latitude, candidate.location.longitude
                )
                if dist < best_dist:
                    best_dist = dist
                    best_idx = idx

            next_act = unvisited.pop(best_idx)
            
            # Compute transit from previous
            dur_mins, cost = estimate_travel_metrics(best_dist, transport_mode)
            transit_mode = "walk" if best_dist <= 1.2 else transport_mode
            
            next_act.travel_from_prev = TravelTransit(
                from_name=current.name,
                to_name=next_act.name,
                mode=transit_mode,
                duration_minutes=dur_mins,
                distance_km=best_dist,
                estimated_cost=cost
            )
            
            ordered.append(next_act)
            current = next_act

        return ordered

    def cluster_activities_by_proximity(self, activities: List[Dict[str, Any]], num_days: int) -> List[List[Dict[str, Any]]]:
        """Group activities into geographical clusters for each day."""
        if not activities:
            return [[] for _ in range(num_days)]
        
        num_days = max(1, num_days)
        # Sort geographically by latitude + longitude
        sorted_acts = sorted(activities, key=lambda x: (x.get("latitude", 0.0) + x.get("longitude", 0.0)))
        
        # Partition into chunks per day
        chunk_size = max(1, math.ceil(len(sorted_acts) / num_days))
        days = []
        for i in range(num_days):
            day_acts = sorted_acts[i * chunk_size : (i + 1) * chunk_size]
            if day_acts:
                days.append(day_acts)
            elif sorted_acts:
                # If short, repeat or pick top ones
                days.append(sorted_acts[:2])
            else:
                days.append([])
        return days

route_optimizer = RouteOptimizer()
