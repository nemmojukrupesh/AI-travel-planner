from sqlalchemy import Column, Integer, String, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.database import Base

class Preference(Base):
    __tablename__ = "preferences"

    id = Column(Integer, primary_key=True, index=True)
    trip_id = Column(String(36), ForeignKey("trips.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    interests = Column(Text, nullable=False, default="[]")  # JSON encoded list of strings
    food_preferences = Column(Text, nullable=False, default="[]")  # JSON encoded list of strings
    accommodation_preference = Column(String(50), nullable=False, default="hotel")  # hotel, hostel, resort, airbnb
    transportation_preference = Column(String(50), nullable=False, default="public_transit")  # public_transit, rental_car, taxi, walking
    special_requirements = Column(Text, nullable=True)

    trip = relationship("Trip", back_populates="preferences")
