from sqlalchemy import Column, String, Integer, Float, ForeignKey, DateTime, Date
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
import uuid
from app.core.database import Base

class Trip(Base):
    __tablename__ = "trips"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    destination = Column(String(255), nullable=False, index=True)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    duration_days = Column(Integer, nullable=False, default=1)
    travelers = Column(Integer, nullable=False, default=1)
    budget = Column(Float, nullable=False)
    currency = Column(String(10), nullable=False, default="USD")
    travel_style = Column(String(50), nullable=False, default="balanced")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="trips")
    preferences = relationship("Preference", back_populates="trip", uselist=False, cascade="all, delete-orphan")
    itineraries = relationship("Itinerary", back_populates="trip", cascade="all, delete-orphan", order_by="Itinerary.version.desc()")
    conversations = relationship("Conversation", back_populates="trip", cascade="all, delete-orphan", order_by="Conversation.created_at.asc()")
