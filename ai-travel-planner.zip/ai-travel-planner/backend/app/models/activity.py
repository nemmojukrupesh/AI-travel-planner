from sqlalchemy import Column, Integer, String, Float, Text
from app.core.database import Base

class Activity(Base):
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True, index=True)
    destination = Column(String(100), nullable=False, index=True)
    name = Column(String(255), nullable=False, index=True)
    category = Column(String(50), nullable=False, index=True)  # historical, nature, adventure, museum, food, shopping, entertainment
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    estimated_cost = Column(Float, nullable=False, default=0.0)
    average_duration = Column(Integer, nullable=False, default=90)  # minutes
    rating = Column(Float, nullable=False, default=4.5)
    opening_hours = Column(String(100), nullable=True, default="09:00 - 18:00")
    is_indoor = Column(Integer, nullable=False, default=0)  # 1 if indoor, 0 if outdoor
    description = Column(Text, nullable=True)
