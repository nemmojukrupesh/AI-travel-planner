import pytest
from app.services.rag.vector_store import vector_store
from app.services.rag.retriever import rag_retriever

def test_vector_store_documents_loaded():
    assert len(vector_store.documents) > 5
    assert len(vector_store.idf) > 20

def test_rag_retrieval_hyderabad():
    result = rag_retriever.retrieve_context(
        query="What are the best historical monuments and places in Hyderabad?",
        destination="Hyderabad",
        top_k=2
    )
    assert "Hyderabad" in result["destination"]
    assert "Charminar" in result["context_text"] or "Golconda" in result["context_text"]
    assert len(result["sources"]) > 0

def test_rag_retrieval_tokyo():
    result = rag_retriever.retrieve_context(
        query="Ramen dining etiquette and Senso-ji temple in Tokyo",
        destination="Tokyo",
        top_k=2
    )
    assert len(result["sources"]) > 0
    assert "Tokyo" in result["destination"]
