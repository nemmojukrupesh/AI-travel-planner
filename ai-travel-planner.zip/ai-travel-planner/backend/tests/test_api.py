import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health_endpoint():
    res = client.get("/")
    assert res.status_code == 200
    data = res.json()
    assert data["status"] == "healthy"

def test_weather_endpoint():
    res = client.get("/api/weather?destination=Paris&days=3")
    assert res.status_code == 200
    data = res.json()
    assert data["destination"] == "Paris"
    assert len(data["daily_forecasts"]) >= 3

def test_places_search_endpoint():
    res = client.get("/api/places/search?destination=Hyderabad&category=historical")
    assert res.status_code == 200
    data = res.json()
    assert data["total_results"] > 0
    assert len(data["places"]) > 0

def test_rag_query_endpoint():
    payload = {
        "query": "historical monuments and Charminar",
        "destination": "Hyderabad",
        "top_k": 2
    }
    res = client.post("/api/rag/query", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "Charminar" in data["grounded_answer_context"] or len(data["sources"]) > 0

def test_trip_full_lifecycle():
    # 1. Register
    reg_payload = {
        "name": "Test Explorer",
        "email": "tester_agent@example.com",
        "password": "Password123!"
    }
    reg_res = client.post("/api/auth/register", json=reg_payload)
    assert reg_res.status_code in [201, 400]  # Created or already exists
    
    # 2. Login
    login_res = client.post("/api/auth/login", json={"email": "tester_agent@example.com", "password": "Password123!"})
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # 3. Create Trip
    trip_payload = {
        "destination": "Hyderabad",
        "start_date": "2026-09-01",
        "end_date": "2026-09-03",
        "travelers": 2,
        "budget": 15000.0,
        "currency": "INR",
        "travel_style": "balanced",
        "preferences": {
            "interests": ["historical", "food"],
            "food_preferences": ["local"],
            "accommodation_preference": "hotel",
            "transportation_preference": "metro"
        }
    }
    create_res = client.post("/api/trips", json=trip_payload, headers=headers)
    assert create_res.status_code == 201
    trip_id = create_res.json()["id"]

    # 4. Generate Itinerary
    gen_res = client.post(f"/api/trips/{trip_id}/generate", headers=headers)
    assert gen_res.status_code == 200
    itin = gen_res.json()
    assert len(itin["days"]) == 3

    # 5. Chat Modification
    chat_payload = {"message": "Make Day 2 cheaper"}
    chat_res = client.post(f"/api/trips/{trip_id}/chat", json=chat_payload, headers=headers)
    assert chat_res.status_code == 200
    assert chat_res.json()["version"] == 2
    assert "cheaper" in chat_res.json()["reply"].lower() or len(chat_res.json()["changes_made"]) > 0

    # 6. Budget optimize endpoint
    opt_res = client.post(f"/api/trips/{trip_id}/budget/optimize", headers=headers)
    assert opt_res.status_code == 200
    assert opt_res.json()["optimized_cost"] > 0
