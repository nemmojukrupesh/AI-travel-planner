import pytest
from app.services.optimizer.route_optimizer import haversine_distance, estimate_travel_metrics, route_optimizer
from app.services.optimizer.budget_optimizer import budget_optimizer
from app.schemas.itinerary import ActivityItem, GeoLocation, TripItinerary, TripSummary, HotelSuggestion, DayPlan, BudgetBreakdown

def test_haversine_distance():
    # Charminar (17.3616, 78.4747) to Chowmahalla Palace (17.3578, 78.4717) ~0.5 km
    dist = haversine_distance(17.3616, 78.4747, 17.3578, 78.4717)
    assert dist > 0.1
    assert dist < 2.0

def test_estimate_travel_metrics():
    walk_dur, walk_cost = estimate_travel_metrics(0.8, "metro")
    assert walk_dur >= 5
    assert walk_cost == 0.0

    transit_dur, transit_cost = estimate_travel_metrics(10.0, "metro")
    assert transit_dur > 15
    assert transit_cost > 10.0

def test_route_optimization_ordering():
    acts = [
        ActivityItem(name="Far North", location=GeoLocation(latitude=17.50, longitude=78.50)),
        ActivityItem(name="Mid Point", location=GeoLocation(latitude=17.40, longitude=78.48)),
        ActivityItem(name="Far South", location=GeoLocation(latitude=17.30, longitude=78.45))
    ]
    optimized = route_optimizer.optimize_day_schedule(acts)
    assert len(optimized) == 3
    assert optimized[1].travel_from_prev is not None
