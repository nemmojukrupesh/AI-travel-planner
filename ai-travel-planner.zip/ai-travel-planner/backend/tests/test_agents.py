import pytest
from app.services.agents.orchestrator import orchestrator
from app.schemas.itinerary import TripItinerary

@pytest.mark.asyncio
async def test_multi_agent_orchestration():
    trip_data = {
        "destination": "Hyderabad",
        "start_date": "2026-09-01",
        "end_date": "2026-09-03",
        "duration_days": 3,
        "travelers": 2,
        "budget": 15000.0,
        "currency": "INR",
        "travel_style": "balanced",
        "interests": ["historical", "food"],
        "food_preferences": ["local", "biryani"],
        "accommodation_preference": "hotel",
        "transportation_preference": "metro"
    }
    itinerary = await orchestrator.plan_trip(trip_data)

    assert isinstance(itinerary, TripItinerary)
    assert itinerary.trip_summary.destination == "Hyderabad"
    assert len(itinerary.days) == 3
    assert itinerary.hotel is not None
    assert itinerary.budget_breakdown is not None
    assert len(itinerary.packing_suggestions) > 0
    assert len(itinerary.safety_recommendations) > 0
