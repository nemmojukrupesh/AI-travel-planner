# VoyageAI - Production-Ready AI Travel Planner

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111.0-009688.svg)](https://fastapi.tiangolo.com)
[![React 18](https://img.shields.io/badge/React-18.3.1-61DAFB.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-3178C6.svg)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4-38B2AC.svg)](https://tailwindcss.com/)
[![Docker](https://img.shields.io/badge/Docker-Compose-2496ED.svg)](https://www.docker.com/)

**VoyageAI** is a full-stack, enterprise-grade AI Travel Planner application engineered to create personalized, budget-aware, weather-aware, and route-optimized travel itineraries using **Multi-Agent AI Orchestration, Grounded RAG, and Modern Full-Stack Technologies**.

---

## 🌟 Key Highlights

* **Autonomous Multi-Agent Architecture**: 8 specialized collaborative agents (`Destination`, `Activity`, `Food`, `Weather`, `RouteOptimizer`, `Budget`, `Itinerary`, and `TravelAssistant`).
* **Grounded RAG System**: TF-IDF & hybrid cosine vector store indexing cultural norms, attraction hours, admission fees, and culinary guides to eliminate hallucinations.
* **Conversational Delta-Modifier**: Conversational Travel Assistant that modifies specific days or constraints in natural language (*"Make Day 2 cheaper"*, *"Add more historical monuments"*, *"Keep travel times under 30 mins"*), creating immutable version snapshots.
* **Intelligent Route Optimization**: Nearest-Neighbor Traveling Salesperson (TSP) heuristic with Haversine distance clustering that minimizes zig-zag transit and estimates transit times and fares.
* **Automated Budget Optimization**: Rebalances accommodation, dining, and activities to fit target budget with visual Recharts breakdown.
* **Multi-LLM & Turnkey Fallback Support**: Compatible with OpenAI (`gpt-4o`), Google Gemini (`gemini-1.5-flash`), Anthropic Claude, and Ollama, paired with a deterministic offline RAG fallback engine for turnkey out-of-the-box evaluation without external API keys.
* **Print-Ready PDF & JSON Export**: Download structured itineraries as styled PDFs or raw JSON.
* **Production Docker Stack**: Multi-stage Dockerfiles with `docker-compose` bundling Frontend, FastAPI Backend, PostgreSQL, and Redis.

---

## 🏗️ System Architecture

```mermaid
graph TD
    User([User / Browser]) <--> ReactApp[React + TypeScript + Vite Frontend]
    ReactApp <--> REST[FastAPI Gateway / API Router]
    
    subgraph "Backend Services"
        Auth[JWT Authentication & Security]
        TripSvc[Trip & Version Manager]
        RAG[RAG Retrieval & Vector Store]
        AgentOrch[Multi-Agent Orchestrator]
        OptEng[Route & Budget Optimization Engine]
        Adapters[External API Service Adapters]
    end
    
    REST --> Auth
    REST --> TripSvc
    REST --> AgentOrch
    REST --> RAG
    
    subgraph "Multi-Agent System"
        AgentOrch --> DestAgent[Destination Agent]
        AgentOrch --> ActAgent[Activity Agent]
        AgentOrch --> WeathAgent[Weather Agent]
        AgentOrch --> RouteAgent[Route Optimization Agent]
        AgentOrch --> FoodAgent[Food & Dining Agent]
        AgentOrch --> BudgAgent[Budget Agent]
        AgentOrch --> ItinAgent[Itinerary Agent]
        AgentOrch --> ChatAgent[Travel Assistant Agent]
    end
    
    subgraph "External Providers & Adapters"
        Adapters --> OpenMeteo[Open-Meteo Weather API]
        Adapters --> OSM[OpenStreetMap Places API]
        Adapters --> CurrencyAPI[Exchange Rates API]
        Adapters --> LLMProviders[OpenAI / Gemini / Anthropic / Fallback LLM]
    end
    
    subgraph "Data & Knowledge Layer"
        DB[(PostgreSQL / SQLite Database)]
        Cache[(Redis / Cache)]
        VectorDB[(RAG Travel Vector Store)]
    end
    
    TripSvc --> DB
    TripSvc --> Cache
    RAG --> VectorDB
```

---

## 🤖 Multi-Agent Pipeline

1. **Destination Agent**: Analyzes destination geography, safety advisories, cultural etiquette, and retrieves grounded RAG context.
2. **Weather Agent**: Fetches real-time multi-day weather forecasts via Open-Meteo, detects rain/extreme heat, and flags outdoor suitability.
3. **Activity Agent**: Selects top attractions matching user interests (e.g. historical, museums, nature, adventure, shopping) and opening hours.
4. **Route Optimization Agent**: Uses the Haversine formula and nearest-neighbor clustering to group daily activities geographically and keep transit times under 20-30 minutes.
5. **Food Agent**: Recommends iconic regional breakfast, lunch, and dinner venues matching user dietary preferences (e.g. Biryani, Vegetarian, Halal, Fine Dining).
6. **Budget Agent**: Computes accommodation, meals, transit, tickets, and miscellaneous buffer expenses. Flags overruns and proposes concrete savings.
7. **Itinerary Agent**: Harmonizes all outputs into a validated Pydantic `TripItinerary` schema with day-by-day schedules, packing checklists, and local safety rules.
8. **Travel Assistant Agent**: Handles natural language chat requests, computes delta-updates to the schedule, and manages version snapshots.

---

## 📁 Repository Structure

```text
ai-travel-planner/
├── backend/
│   ├── app/
│   │   ├── api/v1/          # REST API endpoints (auth, trips, chat, weather, places, budget, rag, export)
│   │   ├── core/            # Configuration, DB engine, security, logging
│   │   ├── models/          # SQLAlchemy ORM models (User, Trip, Preference, Itinerary, Activity, Conversation)
│   │   ├── schemas/         # Pydantic v2 schemas for requests, responses & structured itinerary JSON
│   │   ├── services/
│   │   │   ├── adapters/    # External service adapters (Weather, Places, Currency, Hotel)
│   │   │   ├── agents/      # 8 specialized Multi-Agent implementations + Orchestrator
│   │   │   ├── llm/         # Multi-provider LLM client + Fallback Engine
│   │   │   ├── optimizer/   # Route TSP optimizer & Budget rebalancer
│   │   │   └── rag/         # Vector store, chunking & RAG retriever
│   │   └── main.py          # FastAPI application entrypoint
│   ├── tests/               # Pytest unit and integration test suite
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/      # Modular UI components (itinerary cards, chat drawer, map, budget charts)
│   │   ├── context/         # React AuthContext and ThemeContext (Dark/Light mode)
│   │   ├── pages/           # Landing, Login, Register, Planner Wizard, Dashboard, Saved Trips
│   │   ├── services/        # Axios API clients
│   │   ├── types/           # TypeScript data models
│   │   ├── utils/           # Currency & date formatters
│   │   └── App.tsx          # Router and application root
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
├── docker-compose.yml       # Production multi-container orchestration
├── .env.example             # Configuration template
└── README.md
```

---

## 🚀 Quick Start Guide

### Prerequisites

* Python 3.11+
* Node.js 18+ and npm
* Docker & Docker Compose *(optional for containerized run)*

### 1. Backend Setup

```bash
cd backend

# Create virtual environment (optional)
python -m venv venv
# On Windows:
.\venv\Scripts\activate
# On macOS/Linux:
# source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run backend API server
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Backend will be live at `http://localhost:8000`. Interactive OpenAPI documentation available at `http://localhost:8000/docs`.

### 2. Frontend Setup

```bash
cd frontend

# Install packages
npm install

# Start Vite development server
npm run dev
```

Frontend application will be accessible at `http://localhost:5173`.

---

## 🐳 Docker Deployment

To launch the full stack (Frontend + FastAPI + PostgreSQL + Redis) in one command:

```bash
docker compose up --build
```

Access:
* **Frontend**: `http://localhost`
* **Backend API**: `http://localhost:8000`
* **API Documentation**: `http://localhost:8000/docs`

---

## 🧪 Running Automated Tests

Run the complete backend test suite covering security, agents, RAG search, optimizers, and end-to-end API workflows:

```bash
cd backend
python -m pytest tests/ -v
```

---

## 🔑 Environment Variables Configuration

Copy `.env.example` to `.env`:

```ini
# Security
SECRET_KEY=supersecret_ai_travel_planner_jwt_key_development_2026
DATABASE_URL=sqlite:///./travel_planner.db
REDIS_URL=redis://localhost:6379/0

# LLM Provider (options: fallback, openai, gemini, anthropic, ollama)
LLM_PROVIDER=fallback

# Optional API Keys
OPENAI_API_KEY=
GEMINI_API_KEY=
ANTHROPIC_API_KEY=
WEATHER_API_KEY=
MAPS_API_KEY=
```

> **Note**: VoyageAI works fully out of the box with the default `fallback` engine, utilizing real-time Open-Meteo weather APIs, OpenStreetMap coordinates, and curated RAG knowledge base without requiring paid third-party API keys.

---

## 🛡️ License

MIT License. Designed and built for AI Engineer & Full-Stack Developer portfolios.
